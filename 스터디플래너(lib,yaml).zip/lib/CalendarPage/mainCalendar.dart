
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'dart:ui';


class calendarMain extends StatelessWidget {
  static const routeName = '/month';
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'calender',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: calendarHome(title: 'Calender'),
    );
  }
}





class calendarHome extends StatefulWidget {
  calendarHome({Key key, this.title}) : super(key: key);


  final String title;

  @override
  _calendarHomeState createState() => _calendarHomeState();
}



class _calendarHomeState extends State<calendarHome> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height*3/4,
        child: SfCalendar(
          view: CalendarView.month,
          onTap: (CalendarTapDetails details) {
          },
          /*timeSlotViewSettings: TimeSlotViewSettings(
            timeInterval: const Duration(hours: 4),
          ),*/
          //showNavigationArrow: true,
          //dataSource: MeetingDataSource(meetings),
          monthViewSettings: MonthViewSettings(
            showAgenda: true,
            agendaViewHeight: MediaQuery.of(context).size.height*1/11,
            //agenda는 동그라미로 나오게 하는 거
            //appointmentDisplayCount: 0, //일정 몇개 보이게 할 건지
            //appointmentDisplayMode: MonthAppointmentDisplayMode.appointment,
          ),
          viewHeaderHeight: 80,
          cellBorderColor: Colors.white,
          todayHighlightColor: Colors.orange,
          showDatePickerButton: true,
          selectionDecoration: BoxDecoration(
            color: Colors.transparent,
            border:
            Border.all(color: Colors.orange),
          ),
        ),
      ),

    );
  }

}



enum ColorState { deepOrange, deepPurple, teal, pink, purple, brown}


Color colorChoice = Colors.deepOrange;
SharedPreferences prefs;
//String startDate = DateFormat('yyyy-MM-dd\nHH:mm').format(DateTime.now());
//String endDate = DateFormat('yyyy-MM-dd\nHH:mm').format(DateTime.now());

DateTime startDay = DateTime.now();
DateTime endDay = startDay;
String start = DateFormat('yyyy-MM-dd').format(startDay);
String end = DateFormat('yyyy-MM-dd').format(endDay);


