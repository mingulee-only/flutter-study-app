import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:planner_todo/DiaryNewPage/viewnote.dart';
import 'package:planner_todo/Providers/percentProvider.dart';
import 'package:provider/provider.dart';

import 'addnote.dart';

class DiaryHomePage extends StatefulWidget {
  @override
  _DiaryHomePageState createState() => _DiaryHomePageState();
}

User _user = FirebaseAuth.instance.currentUser;

class _DiaryHomePageState extends State<DiaryHomePage> {

  PercentProvider percentProvider;
  int p=0;

  CollectionReference ref = FirebaseFirestore.instance
      .collection('Todolist').doc(_user.uid)
      .collection('notes');

  @override
  Widget build(BuildContext context) {
    percentProvider = Provider.of<PercentProvider>(context);


    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context)
              .push(
            MaterialPageRoute(
              builder: (context) => AddNote(),
            ),
          )
              .then((value){
            print("Calling Set State !");
            setState(() {});
          });
        },
        child: Icon(
          Icons.add,
          //color: Colors.white70,
        ),
        //backgroundColor: Colors.grey[700],
      ),
/*
      appBar: AppBar(
        title: Text(
          "일기장",
          style: TextStyle(
            fontSize: 24.0,
            fontFamily: "lato",
            fontWeight: FontWeight.bold,
            color: Colors.white60,
          ),
        ),
        elevation: 0.0,
        backgroundColor: Color(0xff070706),
      ),
*/
      body: FutureBuilder<QuerySnapshot>(
        future: ref.orderBy('created', descending: true).get(),
        //시간 역순으로 정렬
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
                itemCount: snapshot.data.docs.length,
                itemBuilder: (context, index) {
                  //Random random = new Random();
                  //Color bg = myColors[random.nextInt(4)];
                  //날짜 확인
                  Map data = snapshot.data.docs[index].data();
                  DateTime mydateTime = data['created'].toDate();
                  String formattedTime = DateFormat('yyyy년 MM월 dd일').format(mydateTime);

                  return InkWell(
                    onTap: (){
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => ViewNote(
                              data,
                              mydateTime,
                              snapshot.data.docs[index].reference
                          ),
                        ),
                      )
                          .then((value) {
                        setState(() {

                          //percentProvider.todoPercentageProvider(mydateTime);
                        });
                      });
                    },
                    child: Card(
                      //color: bg,
                      child: Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(

                              children: [
                                Text(
                                  "${data['title']}",
                                  style: TextStyle(
                                    fontSize: 24.0,
                                    fontFamily: "lato",
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black87,
                                  ),
                                ),
                                /*
                                Spacer(),

                                Text(
                                  "달성도 $p%",
                                  style: TextStyle(
                                    fontSize: 20.0,
                                    fontFamily: "lato",
                                    fontWeight: FontWeight.bold,
                                    color: Colors.brown,
                                  ),
                                ),
                                */
                              ],
                            ),


                            Container(
                              alignment: Alignment.centerRight,
                              child: Text(
                                formattedTime,
                                style: TextStyle(
                                  fontSize: 20.0,
                                  fontFamily: "lato",
                                  color: Colors.black87,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                });
          } else {
            return Center(
              child: Text("Loading..."),
            );
          }
        },
      ),
    );
  }

}
