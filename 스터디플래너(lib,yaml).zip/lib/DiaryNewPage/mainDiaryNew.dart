
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';

import 'mainDiaryPage.dart';

class MainDiaryNew extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: '일기장',
      theme: ThemeData.dark().copyWith(
        primaryColor: Colors.white,
        accentColor: Colors.white,
        scaffoldBackgroundColor: Colors.red,
      ),
      home: DiaryHomePage(),
    );
  }
}