
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_sign_in/google_sign_in.dart';



//로그인 첫번째 페이지
class HomeSignInWidget extends StatelessWidget {
  final Function(int) goToPageCallback;

  HomeSignInWidget({this.goToPageCallback});


  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 24.0,vertical: 30.0),
      child: Column(
        children: [
          /*
          InkWell(
            onTap: (){

            },
            child: Container(
              padding: EdgeInsets.symmetric(
                  vertical: 20.0,
                  horizontal: 20.0
              ),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30.0),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Icon(FontAwesomeIcons.facebookF,
                    size: 20.0,
                  ),
                  Text(' ㅣ  페이스북으로 시작하기',
                    style: TextStyle(
                        color: Colors.red,
                        fontWeight: FontWeight.bold,
                        fontSize: 20.0
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(
            height: 20.0,
          ),
          InkWell(
            onTap: (){

            },
            child: Container(
              padding: EdgeInsets.symmetric(
                  vertical: 20.0,
                  horizontal: 20.0
              ),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30.0),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Icon(FontAwesomeIcons.google,
                    size: 20.0,
                  ),
                  Text(' ㅣ  구글로 시작하기',
                    style: TextStyle(
                        color: Colors.red,
                        fontWeight: FontWeight.bold,
                        fontSize: 20.0
                    ),
                  ),
                ],
              ),
            ),
          ),
          */
          InkWell(
            onTap: (){
              goToPageCallback(1);
            },
            child: Container(
              padding: EdgeInsets.symmetric(
                  vertical: 20.0,
                  horizontal: 20.0
              ),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30.0),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  /*
                  Icon(FontAwesomeIcons.facebookF,
                    size: 20.0,
                  ),*/
                  Text('로그인',
                    style: TextStyle(
                        color: Colors.red,
                        fontWeight: FontWeight.bold,
                        fontSize: 20.0
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(
            height: 20.0,
          ),
          InkWell(onTap: () {
            goToPageCallback(2);  //세 번째 페이지인 회원가입 페이지로 이동
          },
            child: Container(
              padding: EdgeInsets.symmetric(
                  vertical: 20.0,
                  horizontal: 20.0
              ),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30.0),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text('회원가입',
                    style: TextStyle(
                        color: Colors.red,
                        fontWeight: FontWeight.bold,
                        fontSize: 20.0
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(
            height: 20.0,
          ),
          /*
          InkWell(onTap: () {
            goToPageCallback(1); //두 번째 페이지인 로그인 페이지로 이동
          },
            child: Text('계정이 있으신가요? 로그인하세요.',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
                decoration: TextDecoration.underline,
              ),
            ),
          ),
          */
        ],
      ),
    );

  }
}