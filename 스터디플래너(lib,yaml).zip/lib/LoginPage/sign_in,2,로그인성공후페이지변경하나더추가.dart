import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_platform_widgets/flutter_platform_widgets.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:planner_todo/mainPlanner.dart';


class SignIn extends StatefulWidget {
  final Function goToPageSignUp;

  SignIn({this.goToPageSignUp});
  SignIn.login(String email, String password, {this.goToPageSignUp});

  @override
  _SignInState createState() => _SignInState();
  }
  class _SignInState extends State<SignIn> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  String email, password;
  bool _rememberpassword = false;

    void _signIn({String em, String pw}) {

      _auth.signInWithEmailAndPassword(email: em, password: pw).then((authResult) {
        /*Navigator.push(context, MaterialPageRoute(builder: (context)
        {
          return PlannerMain();
          //로그인 성공 시 보여줄 페이지 루트
          return Center(
            child: Text('Welcome ${authResult.user.email}'),
          );
        }));*/

        //이것도 됨(얘는 인자 전달 해주려면 필요할 듯,,
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) => PlannerMain()),
        );
//        Navigator.pushNamed(context, '/plannerMain');
      }).catchError((err) {
        print(err.code);
        if (err.code == 'wrong-password') {
          showCupertinoDialog(
              context: context,
              builder: (context) {
                return CupertinoAlertDialog(
                  title: Text(
                      '비밀번호가 정확하지 않습니다. 다시 입력해주세요'),
                  actions: <Widget>[
                    CupertinoDialogAction(
                      child: Text('OK'),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    )
                  ],
                );
              });
        }
      });

    }





    @override
    Widget build(BuildContext context) {
      return Stack(
        alignment: Alignment.bottomCenter,
        children:[
          Container(
            padding: EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            children: <Widget>[
          Text('로그인',
            style: TextStyle(
                color: Colors.white,
                fontSize: 26.0,
                fontWeight: FontWeight.w600
            ),
          ),
          SizedBox(
            height: 20.0,
          ),
          TextField(
            onChanged: (textVal) {
              setState(() {
                email = textVal;
              });
            },
            decoration: InputDecoration(
              enabledBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: Colors.white
                ),
              ),
              hintText: '이메일을 입력하세요',
              hintStyle: TextStyle(color: Colors.white.withOpacity(0.6)),
              focusColor: Colors.white,
              focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: Colors.white
                ),
              ),
            ),
            style: TextStyle(
                color: Colors.white,
                fontSize: 22.0
            ),
          ),
          SizedBox(
            height: 20.0,
          ),
          TextField(
            onChanged: (textVal) {
            setState(() {
              password = textVal;
            });
          },
            obscureText: true,
            decoration: InputDecoration(
              enabledBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: Colors.white
                ),
              ),
              hintText: '비밀번호',
              hintStyle: TextStyle(color: Colors.white.withOpacity(0.6)),
              focusColor: Colors.white,
              focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: Colors.white
                ),
              ),
            ),
            style: TextStyle(
                color: Colors.white,
                fontSize: 22.0
            ),
          ),
          SizedBox(
            height: 20.0,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Checkbox(
                activeColor: Colors.orange,
                value: _rememberpassword,
                onChanged: (newValue) {
                  setState(() {
                    _rememberpassword = newValue;
                  });
                },
              ),
              SizedBox(
                height: 20.0,
              ),
              Text(
                '비밀번호 기억하기',
                style: TextStyle(
                  color: Colors.white, fontSize: 16.0,
                ),
              ),
              SizedBox(
                width: 20.0,
              ),
              /*
              Text('비밀번호 찾기',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16.0,
                  fontWeight: FontWeight.bold,
                  decoration: TextDecoration.underline,
                ),
              ),*/
            ],
          ),
          SizedBox(
            height: 12.0,
          ),
          InkWell(onTap: () {
            _signIn(em: email, pw: password);
          },
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(
                vertical: 16.0,
                horizontal: 34.0,
              ),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30.0)),
              child: Text(
                '로그인',
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
          SizedBox(
            height: 20.0,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(
                padding: EdgeInsets.all(20.0),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(30.0)),
                child: Icon(
                  FontAwesomeIcons.facebookF,
                  color: Colors.red,
                ),
              ),
              SizedBox(
                width: 38.0,
              ),
              Container(
                padding: EdgeInsets.all(20.0),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(30.0)),
                child: Icon(
                  FontAwesomeIcons.google,
                color: Colors.red,
                ),
              ),
            ],
          ),
          SizedBox(
            height: 20.0,
          ),

        ],
        ),
        ),
          InkWell(
            onTap: (){
              widget.goToPageSignUp();
            },
            child: Container(width: double.infinity,
              padding: EdgeInsets.all(20.0),
                color: Colors.black.withOpacity(0.2),
                child: Text('계정이 없으신가요? 등록하세요.',
                textAlign:TextAlign.center,
                    style: TextStyle(color: Colors.orange, fontWeight: FontWeight.w700)
                ),
            ),
          ),
        ],
      );
    }

    /*
  getRememberInfo() async {
    //logger.d(doRemember);
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      doRemember = (prefs.getBool("doRemember") ?? false);
    });
    if (doRemember) {
      setState(() {
        _mailCon.text = (prefs.getString("userEmail") ?? "");
        _pwCon.text = (prefs.getString("userPasswd") ?? "");
      });
    }
  }

  setRememberInfo() async {
    logger.d(doRemember);

    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool("doRemember", doRemember);
    if (doRemember) {
      prefs.setString("userEmail", _mailCon.text.trim());
      prefs.setString("userPasswd", _pwCon.text.trim());
    }
  }
  */
}
