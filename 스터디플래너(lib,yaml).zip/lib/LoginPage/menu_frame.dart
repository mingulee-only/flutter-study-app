import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:planner_todo/LoginPage/sign_in.dart';


import 'create_login.dart';
import 'home_signin_widget.dart';

//로그인 상단
class MenuFrame extends StatelessWidget {
  PageController pageController = PageController();
  Duration _animationDuration = Duration(milliseconds: 500);

  void _changePage(int page) {
    pageController.animateToPage(page, duration: _animationDuration, curve: Curves.easeIn);
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Container(
        child: Column(
          children: [
            SafeArea( //나만의 공부를 시작하세요! 이렇게 고정되어야 있는 부분
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 28.0, vertical: 40.0),
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(FontAwesomeIcons.calendarAlt,
                        size: 60.0,
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text('MY ',
                          style: TextStyle(
                            fontSize: 34.0,
                            fontWeight: FontWeight.bold,
                            color: Color.fromRGBO(245, 48, 111, 1.0),
                          ),
                        ),
                        Text('TODO',
                          style: TextStyle(
                              fontSize: 34.0,
                              fontWeight: FontWeight.bold,
                              color: Colors.white
                          ),
                        ),
                      ],
                    ),
                    Text(
                      ' 나만의 공부를 시작하세요!',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18.0,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: PageView(
                physics: NeverScrollableScrollPhysics(),  //페이지 옆으로 안 넘어가게 하는 거
                controller: pageController,
                children: <Widget>[
                  //따로 각 페이지마다 함수 정의
                  /*HomeSignInWidget(     //facebook, google, sign up 세 가지, home_signin_widget.dart
                    goToPageCallback: (page) {  //누르면 페이지로 넘어가는 것
                      _changePage(page);
                    },
                  ),*/
                  SignIn(
                    goToPageSignUp: (){
                      _changePage(1); //위에거 하나 지워서 인덱스가 달라짐....
                    }
                  ),     //로그인 페이지
                  CreateLogin(  //로컬 회원가입 페이지
                    pageChange: (page) {  //누르면 제일 처음 페이지로 넘어가는 것
                      _changePage(page);
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
        decoration: BoxDecoration(  //배경 컬러 그라데이션
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color.fromRGBO(255, 123, 67, 1.0),
                Color.fromRGBO(245, 50, 111, 1.0)
              ]
          ),
        ),
      ),
    );
  }
}