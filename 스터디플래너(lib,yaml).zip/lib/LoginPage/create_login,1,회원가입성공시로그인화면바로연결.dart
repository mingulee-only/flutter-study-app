import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';

class CreateLogin extends StatefulWidget {
  final Function cancelBackToHome;
  final Function successSignUp;

  CreateLogin({this.cancelBackToHome, this.successSignUp});
  @override
_State createState() => _State();
}

class _State extends State<CreateLogin> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  String email, password, passwordConfirm;
  bool _termsAgree = false;
  bool saveAttempted = false;
  final formKey = GlobalKey<FormState>();

void showToast(String message){
  Fluttertoast.showToast(msg: message,
  backgroundColor: Colors.white,
  toastLength: Toast.LENGTH_SHORT,
  gravity: ToastGravity.BOTTOM
  );
}

  //회원가입 성공시 띄우는 화면
void _createUser({String email, String pw}) {
  _auth.createUserWithEmailAndPassword(email: email, password: pw)
      .then((authResult) {
    widget.successSignUp();
  }).catchError((err) {
    print(err.code);
    if (err.code == 'email-already-in-use') {
      showCupertinoDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: Text('이메일 확인'),
              content: Text('이미 등록된 이메일 입니다.'),
              actions: <Widget>[
                FlatButton(
                  child: Text('OK'),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
              ],
            );
            CupertinoAlertDialog(
              title: Text(
                  '이미 등록된 이메일 입니다'),
              actions: <Widget>[
                CupertinoDialogAction(
                  child: Text('OK'),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                )
              ],
            );
          });
    }
  });
}
  
  
  @override
Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Container(padding: EdgeInsets.symmetric(horizontal: 24.0),
        child: Column(children: <Widget>[
        Text('CREATE YOUR ACCOUNT',
          style: TextStyle(
              color: Colors.white,
              fontSize: 26.0,
              fontWeight: FontWeight.w600
          ),
        ),
        SizedBox(
          height: 20.0,
        ),
        TextFormField(autovalidate: saveAttempted,
          onChanged: (textValue) {
          setState(() {
            email = textValue;
          });
        },
          validator: (emailValue) {
          if(emailValue.isEmpty) {
            return '필수로 입력해주세요';
          }

          String p = "[a-zA-Z0-9\+\.\_\%\-\+]{1,256}" +
              "\\@" +
              "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
              "(" +
              "\\." +
              "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
              ")+";
          RegExp regExp = new RegExp(p);

          if (regExp.hasMatch(emailValue)) {
            return null;
          }
          return '유효하지 않은 이메일 입니다';
        },
          decoration: InputDecoration(
            errorStyle: TextStyle(color: Colors.white),
              enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: Colors.white
                  ),
              ),
              hintText: '이메일을 입력하세요',
          hintStyle: TextStyle(color: Colors.white.withOpacity(0.6)),
          focusColor: Colors.white,
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: Colors.white
              ),
            ),
          ),
        style: TextStyle(
          color: Colors.white,
          fontSize: 22.0
        ),
        ),
        SizedBox(
          height: 20.0,
        ),
        TextFormField(autovalidate: saveAttempted,
          onChanged: (textValue) {
          setState(() {
            password = textValue;
          });
        },
          validator: (pwValue) {
          if(pwValue.isEmpty) {
            return '필수로 입력해주세요';
          }
          if(pwValue.length <8) {
            return '최소 8자 이상 적어주세요';
          }
          return null;
        },
          obscureText: true,
          decoration: InputDecoration(
            errorStyle: TextStyle(color: Colors.white),
            enabledBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: Colors.white
                ),
            ),
            hintText: '비밀번호를 입력하세요',
            hintStyle: TextStyle(color: Colors.white.withOpacity(0.6)),
            focusColor: Colors.white,
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: Colors.white
              ),
            ),
          ),
          style: TextStyle(
              color: Colors.white,
              fontSize: 22.0
          ),
        ),
        SizedBox(
          height: 20.0,
        ),
        TextFormField(autovalidate: saveAttempted,
          onChanged: (textValue) {
          setState(() {
            passwordConfirm = textValue;
          });
        },
          validator: (pwConfValue) {
          if(pwConfValue != password) {
            return '비밀번호가 일치하지 않습니다';
          }
          return null;
        },

          obscureText: true,
          decoration: InputDecoration(
            errorStyle: TextStyle(color: Colors.white),
            enabledBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: Colors.white
                ),
            ),
            hintText: '비밀번호를 재입력 하세요',
            hintStyle: TextStyle(color: Colors.white.withOpacity(0.6)),
            focusColor: Colors.white,
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: Colors.white
              ),
            ),
          ),
          style: TextStyle(
              color: Colors.white,
              fontSize: 22.0
          ),
        ),
        SizedBox(
          height: 20.0,
        ),
        Row(mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Checkbox(
              activeColor: Colors.orange,
              value: _termsAgree,
              onChanged: (newValue) {
                setState(() {
                  _termsAgree = newValue;
                });
              },
            ),
            SizedBox(
              height: 20.0,
            ),
            Text('약관 및 개인정보 수집 동의',
              style: TextStyle(
              color:  Colors.white,fontSize: 16.0,
            ),
            ),
          ],
        ),
        SizedBox(
          height: 12.0,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            InkWell(
              onTap: () {
              widget.cancelBackToHome();
            },
              child: Text('취소',
              style: TextStyle(
                color: Colors.white,
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
              ),
              ),
            ),
            SizedBox(
              width: 38.0,
            ),
            InkWell(
              onTap: () {
                setState(() {
                  saveAttempted = true;
                });
              if(formKey.currentState.validate()) {
                formKey.currentState.save();
                //showToast("회원가입 성공! 로그인을 해주세요");
                _createUser(email: email,pw: password);
                //widget.successSignUp();
              }
            },
              child: Container(
                padding: EdgeInsets.symmetric(
                  vertical: 16.0,
                  horizontal: 34.0,
              ),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(30.0)),
                child: Text(
                  '회원가입',
                  style: TextStyle(
                    color: Colors.red,
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,),
                ),
              ),
            ),
          ],
        ),
        SizedBox(
          height: 20.0,
        ),
        Text(
          'Agree to Terms & Conditions',
          style: TextStyle(color:  Colors.white),
        ),
      ],
      ),
      ),
    );
}
}