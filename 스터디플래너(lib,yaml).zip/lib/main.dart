import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:planner_todo/CalendarNewPage/calendar_example_DH.dart';
import 'package:planner_todo/DiaryPage/mainDiary.dart';
import 'package:planner_todo/Providers/todayProvider.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

//import 'LoginPage/mainLogin.dart';
import 'ChatExam/mainChatExam.dart';
import 'LoginPage/mainLogin.dart';
import 'Providers/percentProvider.dart';
import 'TodoPage/self_mainTodolist.dart';
import 'mainPlanner.dart';
import 'package:intl/date_symbol_data_local.dart';

/*
void main(){
  runApp(selfApp_todo());
}
*/

/*
final materialThemeData = ThemeData(
    primarySwatch: Colors.blue,
    scaffoldBackgroundColor: Colors.white,
    accentColor: Colors.blue,
    appBarTheme: AppBarTheme(color: Colors.blue.shade600),
    primaryColor: Colors.blue,
    secondaryHeaderColor: Colors.blue,
    canvasColor: Colors.blue,
    backgroundColor: Colors.red,
    textTheme: TextTheme().copyWith(bodyText2: TextTheme().bodyText2));

final cupertinoTheme = CupertinoThemeData(
    primaryColor: Colors.blue,
    barBackgroundColor: Colors.blue,
    scaffoldBackgroundColor: Colors.white);
*/

/**
 Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(PlannerMain());
}

    여기까지가 18번 main
**/

/**
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MultiProvider(
      providers:[
        ChangeNotifierProvider(create: (_) => PercentProvider()),
      ],
      child: PlannerMain()));
}
    //이게 20번 메인
**/

/*
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  initializeDateFormatting().then((_) =>
      runApp(MultiProvider(
      providers:[
        ChangeNotifierProvider(create: (_) => PercentProvider()),
        ChangeNotifierProvider(create: (_) => CalendarDataViewModel()),
      ],
      child: PlannerMain())));
}
//planner 출력(날짜 한글로 수정)

*/

/*
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MultiProvider(
      providers:[
        ChangeNotifierProvider(create: (_) => PercentProvider()),
        ChangeNotifierProvider(create: (_) => CalendarDataViewModel()),
      ],
      child: LoginMain()));
}
//로그인화면 출력

*/

/*
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  initializeDateFormatting('ko', null);
  runApp(MultiProvider(
      providers:[
        ChangeNotifierProvider(create: (_) => PercentProvider()),
        ChangeNotifierProvider(create: (_) => CalendarDataViewModel()),
      ],
      child: LoginMain()));
}
//로그인 찐막 한국어 오류나는 거 이러케 고침
 */
/*
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  initializeDateFormatting('ko', null);
  runApp(MultiProvider(
      providers:[
        ChangeNotifierProvider(create: (_) => PercentProvider()),
        ChangeNotifierProvider(create: (_) => CalendarDataViewModel()),
      ],
      child: LoginMain()));
}
*/


Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  SharedPreferences.setMockInitialValues({});
  initializeDateFormatting('ko', null);
  runApp(MultiProvider(
      providers:[
        ChangeNotifierProvider(create: (_) => PercentProvider()),
        ChangeNotifierProvider(create: (_) => CalendarDataViewModel()),
      ],
      child: LoginMain()));
}