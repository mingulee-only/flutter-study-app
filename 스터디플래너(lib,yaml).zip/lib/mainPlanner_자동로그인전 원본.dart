import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:planner_todo/DiaryPage/mainDiary.dart';

import 'CalendarNewPage/calendar.dart';
import 'CalendarNewPage/calendar_example_DH.dart';
import 'CalendarPage/mainCalendar.dart';
import 'DiaryNewPage/mainDiaryNew.dart';
import 'DiaryNewPage/mainDiaryPage.dart';
import 'TodoPage/self_mainTodolist.dart';

class PlannerMain extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/',
      debugShowCheckedModeBanner: false,
      title: 'main',

      theme: ThemeData(
        primarySwatch: Colors.orange,
        //얘때문에 플로팅 버튼이 오렌지색임
        //테마 지우면 위에 설정해놓은 거 적용됨.
      ),
      home: PlannerMainPage(),
    );
  }
}

class PlannerMainPage extends StatefulWidget {
  @override
  _PlannerMainPageState createState() => _PlannerMainPageState();
}

class _PlannerMainPageState extends State<PlannerMainPage> {

  var _index = 0;
  var _pages = [
    //CalendarPage(),
    CalendarExample(),
    MyHomePage(title: '',),
    DiaryHomePage(),
    Page4(),

  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("열공플래너"),
      ),
      body: _pages[_index],

      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        //3개 이상 했을 때 이거 없으면 안 나옴..
        onTap: (index){
          setState(() {
            _index = index;
          });
        },
        currentIndex: _index,
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
              label: '캘린더',
              icon: Icon(Icons.calendar_today_outlined)
          ),
          BottomNavigationBarItem(
              label: '할 일',
              icon: Icon(Icons.list_alt_rounded)
          ),
          BottomNavigationBarItem(
              label: '일기장',
              icon: Icon(Icons.event_note_rounded)
          ),
          BottomNavigationBarItem(
              label: '스터디그룹',
              icon: Icon(Icons.people_rounded)
          ),
        ],
      ),
    );
  }
}

class Page1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text("1페이지"),

    );
  }
}


class Page2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text("2페이지"),
    );
  }
}

class Page3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DiaryHomePage();
  }
}

class Page4 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text("4페이지"),
    );
  }
}
