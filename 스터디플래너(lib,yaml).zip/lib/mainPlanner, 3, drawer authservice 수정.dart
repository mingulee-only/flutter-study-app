import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:planner_todo/StudyPage/mainStudy.dart';
import 'CalendarNewPage/calendar_example_DH.dart';
import 'DiaryNewPage/mainDiaryNew.dart';
import 'DiaryNewPage/mainDiaryPage.dart';
import 'LoginPage/mainLogin.dart';
import 'LoginPage/sign_in.dart';
import 'StudyPage/newProfile_page.dart';
import 'StudyPage/services/auth_service.dart';
import 'TodoPage/self_mainTodolist.dart';

class PlannerMain extends StatelessWidget {


  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/',
      debugShowCheckedModeBanner: false,
      title: 'main',

      theme: ThemeData(
        primarySwatch: Colors.orange,
        floatingActionButtonTheme: FloatingActionButtonThemeData(
          foregroundColor: Colors.white, //가운데 플러스
        )
        //primaryColor: Colors.white,
        //얘때문에 플로팅 버튼이 오렌지색임
        //테마 지우면 위에 설정해놓은 거 적용됨.
      ),

      home: PlannerMainPage(),
    );
  }
}

class PlannerMainPage extends StatefulWidget {
  @override
  _PlannerMainPageState createState() => _PlannerMainPageState();
}

class _PlannerMainPageState extends State<PlannerMainPage> {
  User user;
  final AuthService _authService = AuthService();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  String _groupName;
  String _userName = '';
  String _email = '';
  Stream _groups;

  var _index = 0;
  var _pages = [
    //CalendarPage(),
    CalendarExample(),
    MyHomePage(title: '',),
    DiaryHomePage(),
    StudyMainPage()
    //HomePage(),

  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("열공플래너"),

      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.symmetric(vertical: 50.0),
          children: <Widget>[
            Icon(Icons.account_circle, size: 150.0, color: Colors.grey[700]),
            SizedBox(height: 15.0),
            Text(_userName, textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 7.0),
            /*
            ListTile(
              onTap: () {},
              selected: true,
              contentPadding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 5.0),
              leading: Icon(Icons.group),
              title: Text('Groups'),
            ),*/

            ListTile(
              onTap: () async {
                Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => PlannerMain()),
                        (Route<dynamic> route) => false);
              },
              contentPadding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 5.0),
              leading: Icon(Icons.date_range_rounded, color: Colors.pinkAccent),
              title: Text('플래너', style: TextStyle(color: Colors.red)),
            ),

            ListTile(
              onTap: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) =>
                        NewProfilePage(userName: _userName, email: _email)));
              },
              contentPadding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 5.0),
              leading: Icon(Icons.account_circle),
              title: Text('프로필'),
            ),
            ListTile(
              onTap: () async {
                await _authService.signOut();
                Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginMain()),
                        (Route<dynamic> route) => false);
              },
              contentPadding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 5.0),
              leading: Icon(Icons.exit_to_app, color: Colors.red),
              title: Text('로그아웃', style: TextStyle(color: Colors.red)),
            ),
          ],
        ),
      ),
      body: _pages[_index],

      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        //3개 이상 했을 때 이거 없으면 안 나옴..
        onTap: (index){
          setState(() {
            _index = index;
          });
        },
        currentIndex: _index,
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
              label: '캘린더',
              icon: Icon(Icons.calendar_today_outlined)
          ),
          BottomNavigationBarItem(
              label: '할 일',
              icon: Icon(Icons.list_alt_rounded)
          ),
          BottomNavigationBarItem(
              label: '일기장',
              icon: Icon(Icons.event_note_rounded)
          ),
          BottomNavigationBarItem(
              label: '스터디그룹',
              icon: Icon(Icons.people_rounded)
          ),
        ],
      ),
    );
  }
}

class Page1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text("1페이지"),

    );
  }
}


class Page2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text("2페이지"),
    );
  }
}

class Page3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DiaryHomePage();
  }
}

class Page4 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text("4페이지"),
    );
  }
}
