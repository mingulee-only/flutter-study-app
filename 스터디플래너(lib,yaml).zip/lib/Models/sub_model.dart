class Subject{
  String subTitle;
  String subColor = "deepOrange";

  Subject();
  Subject.title(this.subTitle);
  Subject.all(this.subTitle, this.subColor);
}