import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';



class Todo{
  String subTitle;
  String todoTitle;
  bool isDone;
  String date = DateFormat('yyyyMMdd').format(DateTime.now());

  Todo();

  Todo.title(this.todoTitle, {this.isDone = false});
  Todo.date(this.todoTitle, this.date, {this.isDone = false});
  Todo.subTitle(this.subTitle);
  Todo.all(this.subTitle, this.todoTitle, {this.isDone = false});
}