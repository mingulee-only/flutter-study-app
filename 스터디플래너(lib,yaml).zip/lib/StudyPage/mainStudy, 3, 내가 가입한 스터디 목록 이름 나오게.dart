import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:planner_todo/ChatExam/helper/helper_functions.dart';
import 'package:planner_todo/ChatExam/pages/search_page.dart';
import 'package:planner_todo/ChatExam/widgets/group_tile.dart';
import 'package:planner_todo/StudyPage/searchAndAddPage.dart';
import 'package:planner_todo/StudyPage/services/auth_service.dart';
import 'package:planner_todo/StudyPage/services/database_service.dart';


class StudyMainPage extends StatefulWidget {
  @override
  _StudyMainPageState createState() => _StudyMainPageState();
}
//User _user = FirebaseAuth.instance.currentUser;

class _StudyMainPageState extends State<StudyMainPage> {

  // data
  final AuthService _auth = AuthService();
  User _user;
  String _groupName;
  String _userName = '';
  String _email = '';
  Stream _userGroups;


  // initState
  @override
  void initState() {
    //_user = FirebaseAuth.instance.currentUser;
    //_groups = FirebaseFirestore.instance.collection("users").doc(_user.uid).snapshots();
    _getUserAuthAndJoinedGroups();
    super.initState();

  }


  // widgets
  Widget noGroupWidget() {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 25.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Center(child: Text("가입된 모임이 없습니다.")),
            Center(child: Text("하단의 추가 버튼을 눌러 새로운 모임을 만들어보세요!")),
          ],
        )
    );
  }



  Widget groupsList() {
    return StreamBuilder(
      stream: _userGroups,
      builder: (context, snapshot) {
        if(snapshot.hasData) {
          if(snapshot.data['groups'] != null) {
            // print(snapshot.data['groups'].length);
            if(snapshot.data['groups'].length != 0) {
              return ListView.builder(
                  itemCount: snapshot.data['groups'].length,
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    int reqIndex = snapshot.data['groups'].length - index - 1;
                    return GroupTile(
                        userName: snapshot.data['fullName'],
                        groupId: _destructureId(snapshot.data['groups'][reqIndex]),
                        groupName: _destructureName(snapshot.data['groups'][reqIndex]),
                        message: "message"
                    );
                  }
              );
            }
            else {
              return noGroupWidget();
            }
          }
          else {
            return noGroupWidget();
          }
        }
        else {
          return Center(
              child: CircularProgressIndicator()
          );
        }
      },
    );
  }


  // functions
  _getUserAuthAndJoinedGroups() async {
    _user = FirebaseAuth.instance.currentUser;
    await HelperFunctions.getUserNameSharedPreference().then((value) {
      setState(() {
        _userName = value;
      });
    });
    DatabaseService(uid: _user.uid).getUserGroups().then((snapshots) {
      // print(snapshots);
      setState(() {
        _userGroups = snapshots;
      });
    });

    await HelperFunctions.getUserEmailSharedPreference().then((value) {
      setState(() {
        _email = value;
      });
    });
  }


  String _destructureId(String res) {
    // print(res.substring(0, res.indexOf('_')));
    return res.substring(0, res.indexOf('_'));
  }


  String _destructureName(String res) {
    // print(res.substring(res.indexOf('_') + 1));
    return res.substring(res.indexOf('_') + 1);
  }





  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //appBar: AppBar(title: Text('스터디 그룹'),),
      floatingActionButton: FloatingActionButton(
        heroTag: "studyMain",
        onPressed: (){
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => SearchAndAddPage()));
        },
        //tooltip: 'Increment',
        child: Icon(Icons.add),
      ),
      body: Column(
        children: [
          Center(child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Text("내가 가입한 스터디",
            style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold,),),
          )),
          Divider(height:2, indent: 15, endIndent: 15, thickness: 2,),
          groupsList(),
        ],
      ),
    );
  }
}
