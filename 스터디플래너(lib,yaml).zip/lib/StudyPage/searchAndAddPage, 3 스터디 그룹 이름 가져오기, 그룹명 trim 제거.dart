import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:planner_todo/ChatExam/helper/helper_functions.dart';
import 'chat_page.dart';
import 'package:planner_todo/StudyPage/services/database_service.dart';


import 'home_screen.dart';


class SearchAndAddPage extends StatefulWidget {
  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchAndAddPage> {

  // data
  TextEditingController searchEditingController = new TextEditingController();
  QuerySnapshot searchResultSnapshot;
  bool isLoading = false;
  bool hasUserSearched = false;
  bool _isJoined = false;
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();


  User _user;
  String _groupName;
  String _userName = '';
  String _email = '';
  Stream _groups;


  // initState()
  @override
  void initState() {
    //super.위에다가 써야됨.
    _getCurrentUserNameAndUid();
    super.initState();
    //_user = FirebaseAuth.instance.currentUser;

  }


  // functions
  _getCurrentUserNameAndUid() async {
    await HelperFunctions.getUserNameSharedPreference().then((value) {
      _userName = value;
    });
    _user = FirebaseAuth.instance.currentUser;
  }


  _initiateSearch() async {
    if(searchEditingController.text.isNotEmpty){
      setState(() {
        isLoading = true;
      });
      await DatabaseService().searchByName(searchEditingController.text).then((snapshot) {
        searchResultSnapshot = snapshot;
        //print("$searchResultSnapshot");
        setState(() {
          isLoading = false;
          hasUserSearched = true;
        });
      });
    }
  }


  void _showScaffold(String message) {
    _scaffoldKey.currentState.showSnackBar(
        SnackBar(
          backgroundColor: Colors.blueAccent,
          duration: Duration(milliseconds: 1500),
          content: Text(message, textAlign: TextAlign.center, style: TextStyle(fontSize: 17.0)),
        )
    );
  }


  _joinValueInGroup(String userName, String groupId, String groupName, String admin) async {
    bool value = await DatabaseService(uid: _user.uid).isUserJoined(groupId, groupName, userName);
    setState(() {
      _isJoined = value;
    });
  }


  // widgets
  Widget groupList() {
    return hasUserSearched ? ListView.builder(
        shrinkWrap: true,
        itemCount: searchResultSnapshot.docs.length,
        itemBuilder: (context, index) {
          return groupTile(
            _userName,
            searchResultSnapshot.docs[index].data()["groupId"],
            searchResultSnapshot.docs[index].data()["groupName"],
            searchResultSnapshot.docs[index].data()["admin"],
          );
        }
    )
        :
    Container();
  }


  Widget groupTile(String userName, String groupId, String groupName, String admin){
    _joinValueInGroup(userName, groupId, groupName, admin);
    return ListTile(
      contentPadding: EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
      leading: CircleAvatar(
          radius: 30.0,
          backgroundColor: Colors.blueAccent,
          child: Text(groupName.substring(0, 1).toUpperCase(), style: TextStyle(color: Colors.white))
      ),
      title: Text(groupName, style: TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text("Admin: $admin"),
      trailing: InkWell(
        onTap: () async {
          await DatabaseService(uid: _user.uid).togglingGroupJoin(groupId, groupName, userName);
          if(_isJoined) {
            setState(() {
              _isJoined = !_isJoined;
            });
            // await DatabaseService(uid: _user.uid).userJoinGroup(groupId, groupName, userName);
            _showScaffold('"$groupName"에 오신 걸 환영합니다!');
            //채팅방 여는 거
            Future.delayed(Duration(milliseconds: 2000), () {
              Navigator.of(context).push(MaterialPageRoute(builder: (context) =>
                  ChatPage(groupId: groupId, userName: userName, groupName: groupName)
              ));
            });
          }
          else {
            setState(() {
              _isJoined = !_isJoined;
            });
            _showScaffold('"$groupName"에서 탈퇴하였습니다.');
          }
        },
        child: _isJoined ? Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10.0),
              color: Colors.black87,
              border: Border.all(
                  color: Colors.white,
                  width: 1.0
              )
          ),
          padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
          child: Text('가입됨', style: TextStyle(color: Colors.white)),
        )
            :
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.0),
            color: Colors.blueAccent,
          ),
          padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
          child: Text('가입하기', style: TextStyle(color: Colors.white)),
        ),
      ),
    );
  }


  // building the search page widget
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,

      floatingActionButton: FloatingActionButton(
        heroTag: null,
        onPressed: () {
          _createGroup();
        },
        child: Icon(Icons.add, color: Colors.amber, size: 30.0),
        //backgroundColor: Colors.orange,
        elevation: 0.0,
      ),

      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: Colors.orange[700],
        title: Text('Search', style: TextStyle(fontSize: 27.0, fontWeight: FontWeight.bold, color: Colors.white)),
      ),
      body: // isLoading ? Container(
      //   child: Center(
      //     child: CircularProgressIndicator(),
      //   ),
      // )
      // :
      Container(
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
              color: Colors.orangeAccent[100],
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: searchEditingController,
                      style: TextStyle(
                        color: Colors.black87,
                      ),
                      decoration: InputDecoration(
                          hintText: "Search groups...",
                          hintStyle: TextStyle(
                              color: Colors.white38,
                              fontSize: 18,
                              fontWeight: FontWeight.bold
                          ),
                          border: InputBorder.none
                      ),
                    ),
                  ),
                  InkWell(
                      onTap: (){
                        _initiateSearch();
                      },
                      child: Container(
                          height: 40,
                          width: 40,
                          decoration: BoxDecoration(
                              color: Colors.orangeAccent[100],
                              borderRadius: BorderRadius.circular(40)
                          ),
                          child: Icon(Icons.search, color: Colors.white)
                      )
                  )
                ],
              ),
            ),
            Expanded(
                //child: HomeScreen()
                child: isLoading ? Container(child: Center(child: CircularProgressIndicator())) : groupList()
            ) //임시데이터 성은이가 만든 그룹 목록 나오는 것
            //isLoading ? Container(child: Center(child: CircularProgressIndicator())) : groupList()
          ],
        ),
      ),
    );
  }


  void _createGroup(){
    showDialog(
      //플러터 기본 함수, 다이어로그  보여주는 거
        context: context,
        builder: (BuildContext context) {
          // 알림화면(title, body, actions)
          return new AlertDialog(
            title: Text("스터디 그룹 만들기"), //추가 수정 완료됨.
            content: TextField(
                onChanged: (val) {
                  _groupName = val.trim();
                },
                style: TextStyle(
                    fontSize: 15.0,
                    height: 2.0,
                    color: Colors.black
                )
            ),
            actions: [
              FlatButton(
                child: Text("Cancel"),
                onPressed:  () {
                  Navigator.of(context).pop();
                },
              ),
              FlatButton(
                child: Text("Create"),
                onPressed:  () async {
                  if(_groupName != null) {
                    DatabaseService(uid: _user.uid).createGroup(_userName, _groupName);
                    Navigator.of(context).pop();
                  }
                },
              ),
            ],
          );
        }
    );
  }

}
