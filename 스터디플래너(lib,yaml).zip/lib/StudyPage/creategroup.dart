import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class CreateGroup extends StatefulWidget {
  @override
  _CreateGroupState createState() => _CreateGroupState();
}

class _CreateGroupState extends State<CreateGroup> {

  String title;
  String members;
  TextEditingController _groupController = TextEditingController();
  TextEditingController _memberController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Row(
                children: [BackButton()],
              ),
            ),
            SizedBox(
              height: 40,
            ),
            Padding(
                padding: const EdgeInsets.all(20.0),
                child: Container(
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _groupController,
                        decoration: InputDecoration(
                          prefixIcon: Icon(Icons.tag_faces),
                          hintText: "그룹 이룸",
                        ),
                        onChanged: (_val){
                          title = _val;
                        },
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      TextFormField(
                        controller: _memberController,
                        decoration: InputDecoration(
                          prefixIcon: Icon(Icons.people),
                          hintText: "인원 수",
                        ),
                        keyboardType: TextInputType.number,
                        onChanged: (_val) {
                          members = _val;
                        },
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      ElevatedButton(
                        onPressed: add,
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 100),
                          child: Text(
                            "만들기",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 20.0
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ) ,
            ),
            Spacer(),
          ],
        ),
      ),
    );
  }

  Future<void> add() async{
    CollectionReference ref = FirebaseFirestore.instance
    .collection('Group').doc('FZJJxqXGVqCpbnx9Ivfi')
        .collection('groups');

    var data = {
      'title': title,
      'members': members,
      'created': DateTime.now(),
    };

    ref.add(data);

    Navigator.pop(context);
  }
}
