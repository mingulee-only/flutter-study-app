import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:intl/intl.dart';
import 'package:planner_todo/ChatExam/helper/helper_functions.dart';
import 'package:planner_todo/StudyPage/services/auth_service.dart';
import 'package:planner_todo/StudyPage/services/database_service.dart';


import 'viewgroup.dart';
import 'creategroup.dart';

//성은이가 만든 임시 데이터, 그룹 목록 나오는 것
class HomeScreen extends StatefulWidget {

  String title;
  String members;

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  CollectionReference ref = FirebaseFirestore.instance
      .collection('Group').doc('FZJJxqXGVqCpbnx9Ivfi')
      .collection('groups');

  final AuthService _authService = AuthService();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  User _user;
  String _groupName;
  String _userName = '';
  String _email = '';
  Stream _groups;

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      resizeToAvoidBottomInset: true,
      //스터디 그룹 추가
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _popupDialog(context);
        },
        child: Icon(Icons.add, color: Colors.white, size: 30.0),
        backgroundColor: Colors.grey[700],
        elevation: 0.0,
      ),
      body: FutureBuilder<QuerySnapshot>(
        future: ref.orderBy('created', descending: true).get(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
                itemCount: snapshot.data.docs.length,
                itemBuilder: (context, index) {
                  Map data = snapshot.data.docs[index].data();
                  //DateTime mydateTime = data['created'].toDate();

                  return InkWell(
                    onTap: () {

                    },
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  "${data['title']}",
                                  style: TextStyle(
                                    fontSize: 24.0,
                                    color: Colors.black,
                                  ),
                                ),
                                Spacer(),
                                Container(
                                  alignment: Alignment.centerRight,
                                  child: Text(
                                    "${data['members']}",
                                    style: TextStyle(
                                      fontSize: 24.0,
                                      color: Colors.pink[300]
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                });
          } else {
            return Center(
              child: Text("로딩 중.."),
            );
          }
        },
      ),
    );
  }

  void _popupDialog(BuildContext context) {
    Widget cancelButton = FlatButton(
      child: Text("Cancel"),
      onPressed:  () {
        Navigator.of(context).pop();
      },
    );
    Widget createButton = FlatButton(
      child: Text("Create"),
      onPressed:  () async {
        if(_groupName != null) {
          await HelperFunctions.getUserNameSharedPreference().then((val) {
            DatabaseService(uid: _user.uid).createGroup(val, _groupName);
          });
          Navigator.of(context).pop();
        }
      },
    );

    AlertDialog alert = AlertDialog(
      title: Text("Create a group"),
      content: TextField(
          onChanged: (val) {
            _groupName = val;
          },
          style: TextStyle(
              fontSize: 15.0,
              height: 2.0,
              color: Colors.black
          )
      ),
      actions: [
        cancelButton,
        createButton,
      ],
    );

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
        /*child: Stack(
          alignment: Alignment.center,
          children: [
            ListView(
              padding: const EdgeInsets.fromLTRB(20.0, 20.0, 20.0, 120.0),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                height: 100.0,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Theme.of(context).scaffoldBackgroundColor.withOpacity(0.1),
                      Theme.of(context).scaffoldBackgroundColor,
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 50.0,
              child: Container(
                padding: const EdgeInsets.all(12.0),
                decoration: BoxDecoration(
                  color: Theme.of(context).accentColor,
                  borderRadius: BorderRadius.circular(26.0),
                ),
                child: IconButton(
                  icon: Icon(Icons.add,
                  size: 25.0,
                  ),
                  onPressed: () {
                    Navigator.of(context)
                        .push(
                      MaterialPageRoute(
                        builder: (context) => CreateGroup(),
                      ),
                    );
                  },
                  ),
                ),
              ),
            /*Positioned(
              bottom: 60.0,
              right: 40.0,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Positioned(
                    right: 4.6,
                    bottom: 11.8,
                    child: Container(
                      height: 16.0,
                      width: 16.0,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Theme.of(context).accentColor,
                      ),
                    ),
                  ),
                ],
              ),
            ),

             */
          ],
        ),
      ),
    );
  }
}*/
