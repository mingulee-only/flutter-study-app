import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'package:planner_todo/ChatExam/widgets/message_tile.dart';
import 'package:planner_todo/StudyPage/services/database_service.dart';
//documents부분 -> docs, data[]부분 -> data()[] 로 수정
//스크롤까지
class ChatPage extends StatefulWidget {

  final String groupId;
  final String userName;
  final String groupName;

  ChatPage({
    this.groupId,
    this.userName,
    this.groupName
  });

  @override
  _ChatPageState createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {

  User _user = FirebaseAuth.instance.currentUser;
  Stream<QuerySnapshot> _chats;
  TextEditingController messageEditingController = new TextEditingController();
  ScrollController _chattingScrollController;
  bool bottomFlag = true;
  String message;
  bool _isJoined = true;

  @override
  void initState() {
    _chattingScrollController = new ScrollController();
    _chattingScrollController.addListener(_scrollListener);
    DatabaseService().getChats(widget.groupId).then((val) {
      // print(val);
      setState(() {
        _chats = val;
      });
    });

    super.initState();
  }

  _scrollListener() async {
    if (_chattingScrollController.offset ==
        _chattingScrollController.position.maxScrollExtent &&
        !_chattingScrollController.position.outOfRange) {
      // top
    } else if (_chattingScrollController.offset <=
        _chattingScrollController.position.maxScrollExtent &&
        !_chattingScrollController.position.outOfRange) {
      // bottom
    }
  }

  Widget _chatMessages(){
    return StreamBuilder(
      stream: _chats,
      builder: (context, snapshot){
        return snapshot.hasData ?  ListView.builder(
          controller: _chattingScrollController,
          itemCount: snapshot.data.docs.length,
          itemBuilder: (context, index){
            if (snapshot.data.docs.length > 0) {
              if (bottomFlag) {
                WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
                  _chattingScrollController.animateTo(
                      _chattingScrollController.position.maxScrollExtent,
                      duration: Duration(milliseconds: 200),
                      curve: Curves.easeInOut);
                  bottomFlag = false;
                });
              }
              return MessageTile(
                message: snapshot.data.docs[index].data()["message"],
                sender: snapshot.data.docs[index].data()["sender"],
                sentByMe: widget.userName == snapshot.data.docs[index].data()["sender"],
              );
            } else {
              return null;
            }

          }
        )
        :
        Container();
      },
    );
  }

  _sendMessage() {
    if (messageEditingController.text.isNotEmpty) {
      Map<String, dynamic> chatMessageMap = {
        "message": messageEditingController.text,
        "sender": widget.userName,
        'time': DateTime.now().millisecondsSinceEpoch,
      };

      DatabaseService().sendMessage(widget.groupId, chatMessageMap);


      setState(() {
        bottomFlag = true;
        messageEditingController.text = "";
      });
    }
  }

  _joinValueInGroup(String userName, String groupId, String groupName) async {
    bool value = await DatabaseService(uid: _user.uid).isUserJoined(groupId, groupName, userName);
    setState(() {
      _isJoined = value;
    });
  }

  void _showScaffold(String message) {
    SnackBar(
          backgroundColor: Colors.deepOrange,
          duration: Duration(milliseconds: 1500),
          content: Text(message, textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17.0)),
        );
  }



  @override
  Widget build(BuildContext context) {
    _joinValueInGroup(widget.userName, widget.groupId, widget.groupName);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.groupName, style: TextStyle(color: Colors.black87)),
        centerTitle: true,
        backgroundColor: Colors.amber[700],
        elevation: 0.0,
        actions: <Widget>[
          IconButton(
              icon: Icon(Icons.exit_to_app_rounded),
              onPressed: () {
                print('그룹 탈퇴');
                setState(() {
                  DatabaseService(uid: _user.uid).togglingGroupJoin(widget.groupId, widget.groupName, widget.userName);
                  _isJoined = false;
                });
                Navigator.pop(context);
                _showScaffold('"${widget.groupName}"에서 탈퇴하였습니다.');
              }
          ),
        ],
      ),
      body: Container(
        child: Column(
          children: <Widget>[
            Expanded(
              child: Container(
                  height:(MediaQuery.of(context).size.height) - 190,
                  child: _chatMessages()),
            ),
            // Container(),
            Container(
              alignment: Alignment.bottomCenter,
              width: MediaQuery.of(context).size.width,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                color: Colors.amber[200],
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: TextField(
                        controller: messageEditingController,
                        style: TextStyle(
                          color: Colors.white
                        ),
                        decoration: InputDecoration(
                          hintText: "메세지 입력 ...",
                          hintStyle: TextStyle(
                            color: Colors.white70,
                            fontSize: 16,
                          ),
                          border: InputBorder.none
                        ),
                      ),
                    ),

                    SizedBox(width: 12.0),

                    GestureDetector(
                      onTap: () {
                        _sendMessage();
                      },
                      child: Container(
                        height: 50.0,
                        width: 50.0,
                        decoration: BoxDecoration(
                          color: Colors.amber,
                          borderRadius: BorderRadius.circular(50)
                        ),
                        child: Center(child: Icon(Icons.send, color: Colors.white)),
                      ),
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
