import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:planner_todo/ChatExam/helper/helper_functions.dart';
import 'package:planner_todo/LoginPage/mainLogin.dart';
import 'package:planner_todo/StudyPage/services/auth_service.dart';
import 'package:planner_todo/StudyPage/services/database_service.dart';

import '../mainPlanner.dart';

class NewProfilePage extends StatefulWidget {
  final String userName;
  final String email;

  NewProfilePage({this.userName, this.email});

  @override
  _NewProfilePageState createState() => _NewProfilePageState();
}

class _NewProfilePageState extends State<NewProfilePage> {

  //String userName;
  //String email;
  User _user;
  final AuthService _authService = AuthService();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  //String _groupName;
  String _username;
  Stream _groups;

  // initState()
  @override
  void initState() {
    //super.위에다가 써야됨.
    //_user = FirebaseAuth.instance.currentUser;
    _username = widget.userName;
    _getCurrentUserNameAndUid();
    super.initState();
    //_user = FirebaseAuth.instance.currentUser;

  }

  _getCurrentUserNameAndUid() async {
    await HelperFunctions.getUserNameSharedPreference().then((value) {
      _username = value;
    });
    _user = FirebaseAuth.instance.currentUser;
  }

  Color getColor(Set<MaterialState> states) {
    const Set<MaterialState> interactiveStates = <MaterialState>{
      MaterialState.pressed,
      MaterialState.hovered,
      MaterialState.focused,
    };
    if (states.any(interactiveStates.contains)) {
      return Colors.deepOrange; //눌렀을 때 색
    }
    return Colors.amber[700];    //누르기 전 색
  }



  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text('Profile', style: TextStyle(color: Colors.white, fontSize: 27.0, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.amberAccent,
        elevation: 0.0,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.symmetric(vertical: 50.0),
          children: <Widget>[
            Icon(Icons.account_circle, size: 150.0, color: Colors.grey[700]),
            SizedBox(height: 15.0),
            Text(widget.userName, textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 7.0),
            /*
            ListTile(
              onTap: () {},
              selected: true,
              contentPadding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 5.0),
              leading: Icon(Icons.group),
              title: Text('Groups'),
            ),*/

            ListTile(
              onTap: () async {
                Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => PlannerMain()),
                        (Route<dynamic> route) => false);
              },
              contentPadding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 5.0),
              leading: Icon(Icons.date_range_rounded, color: Colors.green),
              title: Text('플래너', style: TextStyle(color: Colors.green[700])),
            ),

            ListTile(
              onTap: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) =>
                        NewProfilePage(userName: _username, email: widget.email)));
              },
              contentPadding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 5.0),
              leading: Icon(Icons.account_circle),
              title: Text('프로필'),
            ),
            ListTile(
              onTap: () async {
                await _authService.signOut();
                Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => LoginMain()),
                        (Route<dynamic> route) => false);
              },
              contentPadding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 5.0),
              leading: Icon(Icons.exit_to_app, color: Colors.red),
              title: Text('로그아웃', style: TextStyle(color: Colors.red)),
            ),
          ],
        ),
      ),
      body: Container(
          padding: EdgeInsets.symmetric(horizontal: 40.0, vertical: 140.0),
          child: SingleChildScrollView(
            child: Container(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Icon(Icons.account_circle, size: 200.0, color: Colors.grey[700]),
                  SizedBox(height: 15.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text('Full Name', style: TextStyle(fontSize: 17.0)),
                      Text(_username, style: TextStyle(fontSize: 17.0)),
                    ],
                  ),

                  Divider(height: 20.0),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text('Email', style: TextStyle(fontSize: 17.0)),
                      Text(widget.email, style: TextStyle(fontSize: 17.0)),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: ElevatedButton(
                      style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.resolveWith(getColor),
                      ),
                      onPressed: (){
                        _editFullname();
                      },
                      child: Text("닉네임 변경"),
                    ),
                  )
                ],
              ),
            ),
          )
      ),
    );
  }

  void _editFullname(){

    showDialog(
      //플러터 기본 함수, 다이어로그  보여주는 거
        context: context,
        builder: (BuildContext context) {
          // 알림화면(title, body, actions)
          return new AlertDialog(
            title: Text("닉네임 변경"), //추가 수정 완료됨.
            content: TextField(
                onChanged: (val) {
                  _username = val.trim();
                },
                style: TextStyle(
                    fontSize: 15.0,
                    height: 2.0,
                    color: Colors.black
                )
            ),
            actions: [
              FlatButton(
                child: Text("Cancel"),
                onPressed:  () {
                  Navigator.of(context).pop();
                },
              ),
              FlatButton(
                child: Text("Create"),
                onPressed:  () async {
                  if(_username != null) {
                    DatabaseService(uid: _user.uid).editUserFullnameData(_username);
                    await HelperFunctions.saveUserNameSharedPreference(_username);
                    await HelperFunctions.getUserNameSharedPreference().then((value) {
                      print("Full Name: $value");
                    });

                    Navigator.of(context).pop();
                  }
                },
              ),
            ],
          );
        }
    );
  }

}
