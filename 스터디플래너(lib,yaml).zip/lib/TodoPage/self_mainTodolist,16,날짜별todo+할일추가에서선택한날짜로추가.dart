
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:planner_todo/Models/sub_model.dart';
import 'package:planner_todo/Models/todo_model.dart';
import 'package:planner_todo/TodoPage/self_addTodolist.dart';
import 'package:planner_todo/main.dart';

class SelfApp_todo extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TODO',
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      home: MyHomePage(title: 'TODOLIST'),
    );
  }
}



class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}



class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;
  List<String> sub = ["정보처리기사 실기", "영어", "수학", "졸업작품","전공 공부"];
  List<String> sub1_todo = ["정보처리기사 실기 1단원 공부", "1단원 복습", "1단원 정리", "2단원 복습","정보처리기사 실기 2단원 공부"];

  DateTime today = DateTime.now();
  String percent = "0 %";


  TextEditingController _addListControl = TextEditingController();
  TextEditingController _addSubControl = TextEditingController();

  void dispose(){
    _addListControl.dispose();
    _addSubControl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      /*appBar: AppBar(
        title: Text(widget.title),
      ),*/
      body: Column(
        children: <Widget>[
          _TopDate(),
          _middlePercent(),
          Expanded(child: _todoBottomTodo()),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => AddMeeting()));
        },
        tooltip: 'Increment',
        child: Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }


  Widget _TopDate(){
    String todayStr = DateFormat('yyyy년 MM월 dd일').format(today);
    //날짜 나오는 곳
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget> [
          Text(todayStr, style: TextStyle(fontSize: 20),),
          Row(
            children: [
              IconButton(
                  icon: Icon(Icons.navigate_before),
                  onPressed:(){
                    setState(() {
                      today = today.add(Duration( days: -1));
                    });
                  }
              ),
              SizedBox(width: 10,),
              IconButton(
                  icon: Icon(Icons.navigate_next),
                  onPressed:(){
                    setState(() {
                      today = today.add(Duration( days: 1));
                    });
                  }
              ),
            ],
          ),

        ],
      ),
    );
  }

  Widget _middlePercent(){  //달성도 나오는 곳
    return Container(
      //width: MediaQuery.of(context).size.width,
      //height: MediaQuery.of(context).size.height*1/8,
      color: Colors.deepPurple,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: <Widget> [
              Text('달성도',
                style: TextStyle(
                    fontSize: 15,
                    color: Colors.white
                ),
              ),
              Text(percent,
                style: TextStyle(
                    fontSize: 40,
                  decoration: TextDecoration.underline,
                  color: Colors.white
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _todoBottomTodo(){
   // final todo = Todo.date(doc['todoTitle'], doc['date'], isDone: doc['isDone']);

    String todayDate = DateFormat('yyyyMMdd').format(today);

    return Container(
      //color: Colors.deepOrangeAccent,
      //width: MediaQuery.of(context).size.width,
      //height: MediaQuery.of(context).size.height*5/8,
        child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance.collection('Todolist')
                .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo')
                .where('date', isEqualTo: todayDate).snapshots(),
            //날짜별로
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return Center(
                    child: CircularProgressIndicator()
                );
              }
              final documents = snapshot.data.docs;
              final widgets = documents
                  .map((doc) => _buildTodoListTile(doc)).toList();
              widgets.add(_buildTodoListAddTile());
              return ListView(
                //shrinkWrap: true,
                //primary: false,
                  children: widgets
              );
            }
        )
    );

  }

  Widget _buildTodoListAddTile(){

    return ListTile(
      //tileColor: Colors.red,
      onTap : (){
        setState(() {
          _addListItem();
        });
      },
      leading: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Icon(Icons.add_circle_rounded, color: Colors.black45,),
      ),
      title: Text("할 일 추가",
          style: TextStyle(fontSize: 20, color: Colors.black45)),
    );
  }


  Widget _buildTodoListTile(DocumentSnapshot doc){
    final todo = Todo.date(doc['todoTitle'], doc['date'], isDone: doc['isDone']);

    return ListTile(
      tileColor: Colors.yellow,
      //dense: true,
      //horizontalTitleGap: 20, //leading에서부터 title의 간격?
      minVerticalPadding: 10, //listtile 높이
      //minLeadingWidth: 60,  //leading이랑 타이틀 간격
      onTap: (){
        setState(() {
          _doneTodo(doc);

        });
      },
      onLongPress: (){
        setState(() {
          //업데이트 하면 좋을 듯
        });
      },
      leading: Padding(
        padding: const EdgeInsets.all(15.0),
        child: todo.isDone == false? Icon(
             Icons.check_box_outline_blank_rounded) : Icon(Icons.check_box_rounded),
      ),
      title: Text(
        todo.todoTitle, style: TextStyle(fontSize: 20),
      ),
      trailing: IconButton(
          icon: Icon(Icons.delete_outline_rounded),
          onPressed: (){
            setState(() {
              _deleteListItem(doc);
            });
          }
      ),
    );
  }


  void _addListItem(){
    String todayDate = DateFormat('yyyyMMdd').format(today);
    //todayDate라는 같은 변수 각각 두 번 선언했음 이거 provider로 줘야할지?

    //리스트 추가
    showDialog(
      //플러터 기본 함수, 다이어로그  보여주는 거
        context: context,
        builder: (BuildContext context) {
          // 알림화면(title, body, actions)
          return new AlertDialog(
              title: new Text('할 일 추가'),
              content: SingleChildScrollView(
                child: ListBody(
                  children: [
                    TextField(
                      controller: _addListControl,
                      decoration: InputDecoration(
                          hintText: '할 일 이름 입력'
                      ),
                    ),
                  ],
                ),
              ),
              actions: <Widget>[
                new FlatButton(
                    child: new Text('취소'),
                    onPressed: () {
                      _addListControl.text = '';
                      Navigator.of(context).pop();
                    }
                ),
                new FlatButton(
                    child: new Text('확인'),
                    onPressed: () {
                      _addListControl.text = todayDate;
                      _addDBListItem(Todo.date(_addListControl.text.trim(), todayDate));

                      _addListControl.text = '';
                      Navigator.of(context).pop();
                    }
                )
              ]
          );
        }
    );
  }

  void _addDBListItem(Todo todo){
    FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo')
        .add({
      'todoTitle' : todo.todoTitle,
      'isDone' : todo.isDone,
      'date' : todo.date
    });
  }



  void _deleteDBListItem(DocumentSnapshot doc) {
    FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo')
        .doc(doc.id).delete();
  }


  void _updateDBListItem(Todo todo, DocumentSnapshot doc) {
    FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo')
        .doc(doc.id).update(
        {'subTitle': todo.subTitle,
        'todoTitle' : todo.todoTitle,
        'isDone' : todo.isDone,
        'date' : todo.date}
    );
  }


  void _doneTodo(DocumentSnapshot doc){  //isdone으로 만들어줌 (이거를 tap에다가)
    FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo')
        .doc(doc.id).update(
        {
          'isDone': !doc['isDone'],
        }
    );
  }

  _deleteListItem(DocumentSnapshot doc) {
    final todo = Todo.title(doc['todoTitle']);
    
    //완료처리(*삭제)
    showDialog(
      //플러터 기본 함수, 다이어로그  보여주는 거
        context: context,
        builder: (BuildContext context) {
          // 알림화면(title, body, actions)
          return new AlertDialog(
              title: new Text('"${todo.todoTitle}" 삭제 하시겠습니까?'),
              actions: <Widget>[
                new FlatButton(
                    child: new Text('취소'),
                    onPressed: () => Navigator.of(context).pop()
                ),
                new FlatButton(
                    child: new Text('삭제'),
                    onPressed: () {
                      _deleteDBListItem(doc);
                      Navigator.of(context).pop();
                    }
                )
              ]
          );
        }
    );
  }

}
