import 'package:flutter/material.dart';
import 'package:date_picker_timeline/date_picker_timeline.dart';

void main() => runApp(new TodoApp());


class AddItemScreen extends StatelessWidget {
  //아이템 추가하는 화면(***)
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            title: Text("할 일 추가")
        ),
        body: TextField(
          autofocus: true,
          onSubmitted: (val) {
            Navigator.of(context).pop({'item': val});
          }, //이 부분이 뭔지 모르겠음 val 입력 받아서 앞페이지로 돌아감.
        )
    );
  }

}

class TodoApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Todo List',
        theme: ThemeData(
          primarySwatch: Colors.purple,
        ),
        home: new TodoList()
    );
  }
}


class TodoList extends StatefulWidget {
  @override
  createState() => new TodoListState();
}

class TodoListState extends State<TodoList> {

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
          title: new Text('Todo List')
      ),
      body: _buildToDoList(),
      //플로팅 버튼 누르면 아이템 추가하는 화면으로 연결(***)
      floatingActionButton: new FloatingActionButton(
          onPressed: _navigatorAddItemScreen,
          tooltip: '추가',
          child: new Icon(Icons.add)
      ),
    );
  }

//아이템 추가하는 화면 연결(***)
  _navigatorAddItemScreen() async {
    Map results = await Navigator.of(context)
        .push(new MaterialPageRoute(
      builder: (BuildContext context) {
        return AddItemScreen();
        //위에 잘 모르던 부분 item:어쩌구 이게 mapping 구조
      },
    ));

    //만약 값이 널값이 아니고, key가 item 이면
    if(results != null && results.containsKey("item")) {
      _addTodoItem(results["item"]);  //입력한 맵의 밸류을 가져와서
    }
  }

  _addTodoItem(String item) { //맵의 밸류를 가져와서 ㅇㅇ
    setState(() {
      int index = _todoItems.length;  //list의 길이를 index에 대입
      _todoItems.add(item); //입력한 밸류을 가져와서 list에 저장
    });
  }

  List<String> _todoItems = [];

  //입력한 todolist 출력
  // (todoitem안의 스트링을 실제로 보이게 만듬)
  Widget _buildToDoList() {
    return ListView.builder(
        itemBuilder: (context, index) {
          if(index < _todoItems.length) {
            return _buildToDoItem(_todoItems[index], index);
          }
        }
    );
  }

  //_buildtodolist 하단,
  // listtile(todoItems라는 리스트 안에 있는 스트링을 listtile에 하나씩 대입)
  Widget _buildToDoItem(String todoText, int index) {
    return new ListTile(
      title: Text(todoText),
      onTap: () => _promptRemoveTodoItem(index),
    );
  }


  _promptRemoveTodoItem(int index) {
    //완료처리(*삭제)
    showDialog(
      //플러터 기본 함수, 다이어로그  보여주는 거
        context: context,
        builder: (BuildContext context) {

          return new AlertDialog(
            //알림화면(title, body, actions)
              title: new Text(' "${_todoItems[index]}" 완료 처리 하시겠습니까?'),
              actions: <Widget>[
                new FlatButton(
                    child: new Text('CANCEL'),
                    onPressed: () => Navigator.of(context).pop()
                ),
                new FlatButton(
                    child: new Text('완료'),
                    onPressed: () {
                      _removeTodoItem(index);
                      Navigator.of(context).pop();
                    }
                )
              ]
          );
        }
    );
  }

  //list에서 항목 삭제하는 거
  _removeTodoItem(int index) {
    setState(() => _todoItems.removeAt(index));
  }


}