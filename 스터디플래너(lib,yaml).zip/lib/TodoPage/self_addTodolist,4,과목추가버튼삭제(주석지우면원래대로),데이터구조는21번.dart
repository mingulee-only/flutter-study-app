import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:planner_todo/Models/todo_model.dart';
import 'package:shared_preferences/shared_preferences.dart';


enum ColorState { deepOrange, deepPurple, teal, pink, purple, brown}


Color colorChoice = Colors.deepOrange;
SharedPreferences prefs;
//String startDate = DateFormat('yyyy-MM-dd\nHH:mm').format(DateTime.now());
//String endDate = DateFormat('yyyy-MM-dd\nHH:mm').format(DateTime.now());
Timestamp timestamp = Timestamp.now();
DateTime startDay = DateTime.now();
DateTime endDay = startDay;
String start = DateFormat('yyyy-MM-dd').format(startDay);
String end = DateFormat('yyyy-MM-dd').format(endDay);



List<String> sub = ["정보처리기사 실기", "영어", "수학", "졸업작품","전공 공부"];
List<String> sub1_todo = ["정보처리기사 실기 1단원 공부", "1단원 복습", "1단원 정리", "2단원 복습","정보처리기사 실기 2단원 공부"];
String _selectSub = sub[0];

String todayDate = DateFormat('yyyyMMdd').format(startDay);
/*
class AddTodo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TodoList',
      theme: ThemeData(
        primarySwatch: Colors.red,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: AddMeeting(),
    );
  }
}
*/

//여기에 MaterialApp을 넣으면 pop 했을 때 main으로 안 넘어옴

AddMeetingState pageStateMe;

class AddMeeting extends StatefulWidget {

  @override
  AddMeetingState createState() {
    pageStateMe = AddMeetingState();
    return pageStateMe;
  }
}

class AddMeetingState extends State<AddMeeting> {
  ColorState _colorstate = ColorState.deepOrange;
  SharedPreferences prefs;
  DocumentSnapshot doc;
  String strcolor = 'deepOrange';
  TextEditingController _titleCon = TextEditingController();

  TextStyle tsItem = const TextStyle(
      color: Colors.blueGrey, fontSize: 13, fontWeight: FontWeight.bold);
  TextStyle tsContent = const TextStyle(color: Colors.blueGrey, fontSize: 12);


  final _formkey = GlobalKey<FormState>();



  @override
  void dispose() {
    _titleCon.dispose();
    super.dispose();
  }
/*
  List<Meeting> _addList(List<Meeting> meetings, String title,
      DateTime start, DateTime end, Color color) {
    final DateTime today = DateTime.now();
    final DateTime startTime =
    DateTime(today.year, today.month, today.day+1, 9, 0, 0);
    final endTime = startTime.add(const Duration(hours: 2));
    //meetings.add(Meeting('Conference', startTime, endTime, const Color(0xFF0F8644), false));
    meetings.add(Meeting(
        title, start, end, color, true));

    return meetings;
  }
*/
  Future<DateTime> selectedDate(BuildContext context){
    Future<DateTime> dateSelect = showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2030,12,31),
    );

    return dateSelect;
  }


  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: Text('일정 입력'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Form(
          key: _formkey,
          child: Column(
            children: <Widget>[
              SizedBox(
                height: 60,
                child: TextFormField(
                    style: TextStyle(fontSize: 20),
                    decoration: InputDecoration(
                      hintText: '\t\t일정 타이틀 입력',
                    ),
                    controller: _titleCon,
                    validator:(value) {
                      if (value
                          .trim()
                          .isEmpty) {
                        value = '내 일정';
                      }
                      return null;
                    }
                ),
              ),
              /*
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  //mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Row(
                      children: [
                        Icon(Icons.all_inbox_rounded),
                        SizedBox(width: 20,),
                        Text("과목 선택", style: TextStyle(fontSize: 20),),
                      ],
                    ),
                    Expanded(
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: SizedBox(
                            height: 50,
                            child: DropdownButton(
                              style: TextStyle(fontSize: 18, color: Colors.black54, fontWeight: FontWeight.w600),
                              value: _selectSub,
                              items: sub.map(
                                    (value) {
                                  return DropdownMenuItem(
                                    value: value,
                                    child: Text(value),
                                  );
                                },
                              ).toList(),
                              onChanged: (value){
                                setState(() {
                                  _selectSub = value;
                                });
                              },
                            )
                        ),
                      ),
                    ),

                  ]
                ),
              ),
              */
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Container(
                          alignment: Alignment.centerLeft,
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              Icon(Icons.calendar_today_rounded),
                              SizedBox(width: 20,),
                              Text(
                                "날짜 설정", style: TextStyle(fontSize: 20,),
                              ),
                            ],
                          )
                      ),
                      Row(
                        children: <Widget>[
                          Padding(padding: EdgeInsets.all(20.0)),
                          FlatButton(
                              onPressed: () {
                                Future<DateTime> startDate = showDatePicker(
                                  context: context,
                                  initialDate: startDay,
                                  firstDate: DateTime(2000),
                                  lastDate: DateTime(2030,12,31),
                                );
                                startDate.then((date) {
                                  setState(() {
                                    startDay = date;
                                    start = DateFormat('yyyy-MM-dd').format(startDay);
                                    endDay = startDay;
                                    end = DateFormat('yyyy-MM-dd').format(endDay);
                                    //todayDate = DateFormat('yyyyMMdd').format(startDay);
                                  });
                                });
                              },
                              child: Text(
                                '$start',
                                textAlign: TextAlign.center,
                                style: TextStyle(color: Colors.black54, fontSize: 18.0),
                              )),
                          /*Icon(
                            Icons.chevron_right,
                            size: 35.0,
                          ),
                          FlatButton(
                              onPressed: () {
                                Future<DateTime> endDate = showDatePicker(
                                  context: context,
                                  initialDate: endDay,
                                  firstDate: DateTime(2000),
                                  lastDate: DateTime(2030,12,31),
                                );
                                endDate.then((date) {
                                  setState(() {
                                    endDay = date;
                                    end = DateFormat('yyyy-MM-dd').format(endDay);
                                  });
                                });
                              },
                              child: Text(
                                end,
                                textAlign: TextAlign.center,
                                style: TextStyle(color: Colors.black54, fontSize: 18.0),
                              )),*/
                        ],
                      ),
                      /*Container(
                          alignment: Alignment.centerLeft,
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              Icon(Icons.create),
                              SizedBox(width: 20,),
                              Text(
                                "색상 선택", style: TextStyle(fontSize: 20,),
                              ),
                            ],
                          )
                      ),
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Container(
                              decoration:_colorstate == ColorState.deepOrange?
                              BoxDecoration(
                                  borderRadius: BorderRadius.circular(60),
                                  border: Border.all(width: 5, color: Colors.amberAccent)):null,
                              child: CircleAvatar(
                                child: FlatButton(
                                  onPressed: (){
                                    setState(() {
                                      _colorstate = ColorState.deepOrange;
                                      colorChoice = Colors.deepOrange;
                                      strcolor = 'deepOrange';
                                    });
                                  },
                                ),
                                backgroundColor: Colors.deepOrange,
                              ),
                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Container(
                              decoration:_colorstate == ColorState.deepPurple?
                              BoxDecoration(
                                  borderRadius: BorderRadius.circular(60),
                                  border: Border.all(width: 5, color: Colors.amberAccent)):null,
                              child: CircleAvatar(
                                child: FlatButton(
                                  onPressed: (){
                                    setState(() {
                                      _colorstate = ColorState.deepPurple;
                                      colorChoice = Colors.deepPurple;
                                      strcolor = 'deepPurple';
                                    });
                                  },
                                ),
                                backgroundColor: Colors.deepPurple,
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Container(
                              decoration:_colorstate == ColorState.teal?
                              BoxDecoration(
                                  borderRadius: BorderRadius.circular(60),
                                  border: Border.all(width: 5, color: Colors.amberAccent)):null,
                              child: CircleAvatar(
                                child: FlatButton(
                                  onPressed: (){
                                    setState(() {
                                      _colorstate = ColorState.teal;
                                      colorChoice = Colors.teal;
                                      strcolor = 'teal';
                                    });
                                  },
                                ),
                                backgroundColor: Colors.teal,
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Container(
                              decoration:_colorstate == ColorState.pink?
                              BoxDecoration(
                                  borderRadius: BorderRadius.circular(60),
                                  border: Border.all(width: 5, color: Colors.amberAccent)):null,
                              child: CircleAvatar(
                                child: FlatButton(
                                  onPressed: (){
                                    setState(() {
                                      _colorstate = ColorState.pink;
                                      colorChoice = Colors.pink;
                                      strcolor = 'pink';
                                    });
                                  },
                                ),
                                backgroundColor: Colors.pink,
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Container(
                              decoration:_colorstate == ColorState.purple?
                              BoxDecoration(
                                  borderRadius: BorderRadius.circular(60),
                                  border: Border.all(width: 5, color: Colors.amberAccent)):null,
                              child: CircleAvatar(
                                child: FlatButton(
                                  onPressed: (){
                                    setState(() {
                                      _colorstate = ColorState.purple;
                                      colorChoice = Colors.purple;
                                      strcolor = 'purple';
                                    });
                                  },
                                ),
                                backgroundColor: Colors.purple,
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Container(
                              decoration: _colorstate == ColorState.brown?
                              BoxDecoration(
                                  borderRadius: BorderRadius.circular(60),
                                  border: Border.all(width: 5, color: Colors.amberAccent)): null,
                              child: CircleAvatar(
                                child: FlatButton(
                                  onPressed: (){
                                    setState(() {
                                      _colorstate = ColorState.brown;
                                      colorChoice = Colors.brown;
                                      strcolor = 'brown';
                                    });
                                  },
                                ),
                                backgroundColor: Colors.brown,
                              ),
                            ),
                          ),

                        ],
                      )*/
                    ],
                  ),
                ),
              ),
              Container(
                child: Row(
                  children: [
                    Expanded(
                      child: FlatButton(
                        child: Text('취소'),
                        onPressed: () async {
                          _initList();
                          Navigator.pop(context);
                        },
                      ),
                    ),
                    Expanded(
                      child: FlatButton(
                        child: Text('확인'),
                        onPressed: () async {
                          _addList(Todo.all(_selectSub, _titleCon.text.trim()));
                          _initList();
                          Navigator.pop(context);

                          setState(() {

                          });
                        },
                      ),
                    ),
                  ],
                ),
              ),

            ],
          ),
        ),
      ),
    );

  }

  void _initList(){
    startDay = DateTime.now();
    start = DateFormat('yyyy-MM-dd').format(startDay);
    _selectSub = sub[0];
  }

  void _addList(Todo todo){
    FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo').add({
      'date' : todayDate,
      'isDone' : todo.isDone,
      'subTitle' : todo.subTitle,
      'todoTitle' : todo.todoTitle
    });
  }




}

