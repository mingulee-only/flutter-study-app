import 'package:flutter/material.dart';
import 'package:planner_todo/groupchatmain.dart';


// 날짜 변경 가능, todolist 출력되게 하는 것까지 했음.
class SelfApp_todo extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TODO',
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      home: MyHomePage(title: 'Flutter Todo page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;
  List<String> sub = ["정보처리기사 실기", "영어", "수학", "졸업작품","전공 공부"];
  List<String> sub1_todo = ["정보처리기사 실기 1단원 공부", "정보처리기사 실기 2단원 공부"];

  DateTime today = DateTime.now();

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Column(
        children: <Widget>[
          _TopDate(),
          _middlePercent(),
          _bottomTodo(),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }


  Widget _TopDate(){  //날짜 나오는 곳
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget> [
          Text("${today.year}년 ${today.month}월 "
              "${today.day}일", style: TextStyle(fontSize: 20),),
          Row(
            children: [
              IconButton(
                  icon: Icon(Icons.navigate_before),
                  onPressed:(){
                    setState(() {
                      today = today.add(Duration( days: -1));
                    });
                  }
              ),
              SizedBox(width: 10,),
              IconButton(
                  icon: Icon(Icons.navigate_next),
                  onPressed:(){
                    setState(() {
                      today = today.add(Duration( days: 1));
                    });
                  }
              ),
            ],
          ),

        ],
      ),
    );
  }

  Widget _middlePercent(){  //달성도 나오는 곳
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height*1/8,
      color: Colors.yellow,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Center(
            child: Column(
              children: <Widget> [
                Text('달성도',
                  style: TextStyle(fontSize: 15),),
                Text('100%',
                  style: TextStyle(fontSize: 40, decoration: TextDecoration.underline),),
              ],
            )
        ),
      ),
    );
  }

  Widget _bottomTodo(){
    return Container(
      color: Colors.deepOrangeAccent,
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height*5/8,
      child: Column(
        children: <Widget>[
          for(int i = 0; i < sub.length ; i++)
            Container(
              child: SingleChildScrollView(
                child: Column(  //todo 과목별 큰 묶음(1과목+1과목todolist)
                  children: [
                    Container(
                      //width: MediaQuery.of(context).size.width,
                      //height: MediaQuery.of(context).size.height*1/9,
                      decoration: BoxDecoration(
                          color: Colors.orange,
                          border: Border.all(color: Colors.white, width: 1)),
                      child: Column(  //todo 과목 라인(반복)
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(    //todo 과목 라인
                              children:[
                                Expanded(
                                  child: Row(    //과목 아이콘이랑 제목
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.all(10.0),
                                        child: Icon(Icons.create),
                                      ),
                                      Center(child: Text(sub[i], style: TextStyle(fontSize: 20),)),
                                    ],
                                  ),
                                ),
                                Row(    //todo 추가할 버튼
                                  children: [
                                    IconButton(
                                        icon: Icon(Icons.add),
                                        onPressed: (){}
                                    ),
                                  ],
                                ),
                              ]
                          ),

                        ],
                      ),

                    ),
                    Column( //todolist
                      children: <Widget> [
                        if(sub[i] == "정보처리기사 실기")
                          for(int j = 0 ; j < sub1_todo.length; j++)
                            Container(
                              width: MediaQuery.of(context).size.width,
                              height: MediaQuery.of(context).size.height*1/18,
                              decoration: BoxDecoration(
                                  color: Colors.orangeAccent,
                                  border: Border.all(color: Colors.white, width: 1)),
                              child: Row(
                                children: <Widget> [
                                  SizedBox( width : 50 ),
                                  Text("${sub1_todo[j]}",
                                    style: TextStyle(fontSize: 15),)
                                ],
                              ),
                            ),
                      ],
                    )
                  ],
                ),
              ),
            ),

        ],
      ),
    );
  }

}
