
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:planner_todo/Models/sub_model.dart';
import 'package:planner_todo/Models/todo_model.dart';
import 'package:planner_todo/TodoPage/self_addTodolist.dart';
import 'package:planner_todo/groupchatmain.dart';

class SelfApp_todo extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TODO',
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      home: MyHomePage(title: 'TODOLIST'),
    );
  }
}



class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}


class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;
  List<String> sub = ["정보처리기사 실기", "영어", "수학", "졸업작품","전공 공부"];
  List<String> sub1_todo = ["정보처리기사 실기 1단원 공부", "1단원 복습", "1단원 정리", "2단원 복습","정보처리기사 실기 2단원 공부"];

  DateTime today = DateTime.now();

  TextEditingController _addListControl = TextEditingController();
  TextEditingController _addSubControl = TextEditingController();

  void dispose(){
    _addListControl.dispose();
    _addSubControl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      /*appBar: AppBar(
        title: Text(widget.title),
      ),*/
      body: Column(
        children: <Widget>[
          _TopDate(),
          _middlePercent(),
          Expanded(child: _newBottomTodo()),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => AddMeeting()));
        },
        tooltip: 'Increment',
        child: Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }


  Widget _TopDate(){  //날짜 나오는 곳
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget> [
          Text("${today.year}년 ${today.month}월 "
              "${today.day}일", style: TextStyle(fontSize: 20),),
          Row(
            children: [
              IconButton(
                  icon: Icon(Icons.navigate_before),
                  onPressed:(){
                    setState(() {
                      today = today.add(Duration( days: -1));
                    });
                  }
              ),
              SizedBox(width: 10,),
              IconButton(
                  icon: Icon(Icons.navigate_next),
                  onPressed:(){
                    setState(() {
                      today = today.add(Duration( days: 1));
                    });
                  }
              ),
            ],
          ),

        ],
      ),
    );
  }

  Widget _middlePercent(){  //달성도 나오는 곳
    return Container(
      //width: MediaQuery.of(context).size.width,
      //height: MediaQuery.of(context).size.height*1/8,
      color: Colors.deepPurple,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: <Widget> [
              Text('달성도',
                style: TextStyle(
                    fontSize: 15,
                    color: Colors.white
                ),
              ),
              Text('100%',
                style: TextStyle(
                    fontSize: 40,
                  decoration: TextDecoration.underline,
                  color: Colors.white
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _bottomTodo(){

    return Container(
      //color: Colors.deepOrangeAccent,
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height*5/8,
      child: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            for(int i = 0 ; i < sub.length ; i++)
              Container(
                child: Column(  //todo 과목별 큰 묶음(1과목+1과목todolist)
                  children: [
                    Container(
                      //width: MediaQuery.of(context).size.width,
                      //height: MediaQuery.of(context).size.height*1/9,
                      decoration: BoxDecoration(
                        //color: Colors.orange,
                          border: Border.all(color: Colors.grey, width: 1)),
                      child: Column(  //todo 과목 라인(반복)
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(    //todo 과목 라인
                              children:[
                                Expanded(
                                  child: Row(    //과목 아이콘이랑 제목
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.all(15.0),
                                        child: Icon(Icons.create),
                                      ),
                                      Center(child: Text(sub[i], style: TextStyle(fontSize: 20),)),
                                    ],
                                  ),
                                ),
                                Row(    //todo 추가할 버튼
                                  children: [
                                    IconButton(
                                        icon: Icon(Icons.add),
                                        onPressed: (){
                                          setState(() {
                                            //_addTodoItem(sub[i]);
                                          });

                                        }
                                    ),
                                  ],
                                ),
                              ]
                          ),
                        ],
                      ),

                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 20.0),
                      child: Column( //todolist
                        children: <Widget> [
                          if(sub[i] == "정보처리기사 실기")
                            _buildToDoList()
                        ],
                      ),
                    )
                  ],

                ),
              ),
            InkWell(
              onTap: (){
                _addSubItem();
              },
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Icon(Icons.add_circle_rounded, color: Colors.grey,),
                  ),
                  Center(child: Text("과목 추가", style: TextStyle(fontSize: 20),)),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _newBottomTodo(){
    return Container(
      //color: Colors.deepOrangeAccent,
      //width: MediaQuery.of(context).size.width,
      //height: MediaQuery.of(context).size.height*5/8,
      child: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Subject').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return CircularProgressIndicator();
          }
          final documents = snapshot.data.docs;
          final widgets = documents
              .map((doc) => _buildSubListTile(doc)).toList();
          widgets.add(_buildSubListAddTile());
          return ListView(
            //shrinkWrap: true,
            //primary: false,
            children: widgets
          );
        }
      )
    );

  }

  Widget _buildSubListAddTile(){

    return ListTile(
      //tileColor: Colors.red,
      onTap : (){
        setState(() {
          _addSubjectItem();
        });
      },
      leading: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Icon(Icons.add_circle_rounded, color: Colors.black45,),
      ),
      title: Text("과목 추가",
          style: TextStyle(fontSize: 20, color: Colors.black45)),
    );
    /*
    return InkWell(
      onTap: (){
        _addSubjectItem();
      },
      child: Row(
        children: [
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: Icon(Icons.add_circle_rounded, color: Colors.grey,),
          ),
          Center(child: Text("과목 추가", style: TextStyle(fontSize: 20),)),
        ],
      ),
    );*/
  }

  Widget _buildSubListTile(DocumentSnapshot doc){
    final sub = Subject.title(doc['subTitle']);
    return ListTile(
          tileColor: Colors.yellow,
          //dense: true,
          //horizontalTitleGap: 20, //leading에서부터 title의 간격?
          minVerticalPadding: 20, //listtile 높이
          //minLeadingWidth: 60,  //leading이랑 타이틀 간격
          onTap: (){
            setState(() {
              _deleteSubjectItem(doc);
            });
          },
          onLongPress: (){
            setState(() {
              //업데이트 하면 좋을 듯
            });
          },
          leading: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Icon(Icons.edit_rounded),
          ),
          title: Text(
              sub.subTitle, style: TextStyle(fontSize: 20),
          ),
          trailing: IconButton(
              icon: Icon(Icons.add),
              onPressed: (){
                setState(() {
                  _addTodoItem(doc);
                });
              }
          ),
      );
  }

  void _addSubjectItem(){
    //리스트 추가
    showDialog(
      //플러터 기본 함수, 다이어로그  보여주는 거
        context: context,
        builder: (BuildContext context) {
          // 알림화면(title, body, actions)
          return new AlertDialog(
              title: new Text('과목 추가'),
              content: SingleChildScrollView(
                child: ListBody(
                  children: [
                    TextField(
                      controller: _addSubControl,
                      decoration: InputDecoration(
                          hintText: '과목 이름 입력'
                      ),
                    ),
                  ],
                ),
              ),
              actions: <Widget>[
                new FlatButton(
                    child: new Text('취소'),
                    onPressed: () {
                      _addSubControl.text = '';
                      Navigator.of(context).pop();
                    }
                ),
                new FlatButton(
                    child: new Text('확인'),
                    onPressed: () {
                      _addDBSubjectItem(Subject.title(_addSubControl.text.trim()));
                      _addSubControl.text = '';
                      Navigator.of(context).pop();
                    }
                )
              ]
          );
        }
    );
  }

  void _addDBSubjectItem(Subject subject){
    FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Subject')
        .add({
      'subTitle' : subject.subTitle,
      'subColor' : subject.subColor
    });
  }

  void _deleteDBSubjectItem(DocumentSnapshot doc) {
    FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Subject')
        .doc(doc.id).delete();
  }

  void _updateDBSubjectItem(Subject subject, DocumentSnapshot doc) {
    FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Subject')
        .doc(doc.id).update(
        {'subTitle': subject.subTitle,
          'subColor' : subject.subColor}
    );
  }

  void _updateDBTodoItem(Todo todo, DocumentSnapshot doc) {
    FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo')
        .doc(doc.id).update(
        {'subTitle': todo.subTitle,
        'todoTitle' : todo.todoTitle,
        'isDone' : todo.isDone,
        'date' : todo.date}
    );
  }


  _deleteSubjectItem(DocumentSnapshot doc) {
    final sub = Subject.title(doc['subTitle']);
    
    //완료처리(*삭제)
    showDialog(
      //플러터 기본 함수, 다이어로그  보여주는 거
        context: context,
        builder: (BuildContext context) {
          // 알림화면(title, body, actions)
          return new AlertDialog(
              title: new Text('"${sub.subTitle}" 삭제 하시겠습니까?'),
              actions: <Widget>[
                new FlatButton(
                    child: new Text('취소'),
                    onPressed: () => Navigator.of(context).pop()
                ),
                new FlatButton(
                    child: new Text('삭제'),
                    onPressed: () {
                      _deleteDBSubjectItem(doc);
                      Navigator.of(context).pop();
                    }
                )
              ]
          );
        }
    );
  }

  _addTodoItem(DocumentSnapshot doc){
    final sub = Subject.title(doc['subTitle']);

    //리스트 추가
    showDialog(
      //플러터 기본 함수, 다이어로그  보여주는 거
        context: context,
        builder: (BuildContext context) {
          // 알림화면(title, body, actions)
          return new AlertDialog(
              title: new Text('할 일 추가'),
              content: SingleChildScrollView(
                child: ListBody(
                  children: [
                    Text(sub.subTitle),
                    TextField(
                      controller: _addListControl,
                      decoration: InputDecoration(
                          hintText: '할 일을 입력하세요'
                      ),
                    ),
                  ],
                ),
              ),
              actions: <Widget>[
                new FlatButton(
                    child: new Text('취소'),
                    onPressed: () {
                      _addListControl.text='';
                      Navigator.of(context).pop();
                    }
                ),
                new FlatButton(
                    child: new Text('확인'),
                    onPressed: () {
                      _addDBTodoItem(Todo.all(sub.subTitle, _addListControl.text.trim()));
                      _addListControl.text='';
                      Navigator.of(context).pop();
                    }
                )
              ]
          );
        }
    );
  }

  _addDBTodoItem(Todo todo){
    FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo')
        .add({
      'subTitle' : todo.subTitle,
      'todoTitle' : todo.todoTitle,
      'isDone' : todo.isDone,
      'date' : todo.date
    });
  }


  //과목별 todolist listView
  Widget _buildToDoList() {
    DocumentSnapshot doc;
    StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('Todolist')
      .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo').snapshots(),
      builder: (context, snapshot) {
        if(!snapshot.hasData){
          return CircularProgressIndicator();
        }
        final documents = snapshot.data.docs;
        return Expanded(
          child: Row(
            children: [
              ListView(
                children: documents
                    .map((DocumentSnapshot doc)
                => _buildllistWidget(doc)),
              ),
              
            ],
          ),
        );
      },
    );
    
    //구분선 없앰
  }

  Widget _buildllistWidget(DocumentSnapshot doc){
    final todo = Todo.all(doc['subTitle'], doc['todoTitle']);
    return ListTile(
      onTap:() => _toggleTodo(doc),
      title: Text(
        todo.todoTitle,
        style: todo.isDone? TextStyle(
          decoration: TextDecoration.lineThrough,
          fontStyle: FontStyle.italic,
        ) : null, //todo 아직 안 끝나면 적용 X
      ),
      trailing: IconButton(
        icon: Icon(Icons.delete_forever),
        onPressed: () => _deleteTodo(doc),    //todo 쓰레기통  클릭시 삭제되도록 수정
      ),
    );
  }

  void _deleteTodo(DocumentSnapshot doc) {
    FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo').doc(doc.id).delete();
  }

  void _toggleTodo(DocumentSnapshot doc){  //isdone으로 만들어줌 (이거를 tap에다가)
    FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo').doc(doc.id).update({
      'isDone': !doc['isDone'],
    });
  }

  //과목별 todolist listTile
  Widget _buildItemWidget(DocumentSnapshot doc){
    final todo = Todo.all(doc['subTitle'], doc['todoTitle']);

    //height: MediaQuery.of(context).size.height*1/18,
    return ListTile(
      onTap:(){
        todo.isDone = !todo.isDone;
      },
      leading: todo.isDone == false? Icon(Icons.check_box_outline_blank_rounded): Icon(Icons.check_box_rounded),
      title: Text(
        todo.todoTitle,
        style: /*todo.isDone? TextStyle(
          decoration: TextDecoration.lineThrough,
          fontStyle: FontStyle.italic,
        ) :*/ null, //todo 아직 안 끝나면 적용 X
      ),
      contentPadding: EdgeInsets.symmetric(vertical: 0.0, horizontal: 10.0),
      //양쪽 여백, 위아래 여백
      trailing: IconButton(
        icon: Icon(Icons.delete_outline_rounded),
        onPressed: () {
          //_promptRemoveTodoItem(index);
        }   //todo 쓰레기통  클릭시 삭제되도록 수정
      ),
    );
  }

  //_buildtodolist 하단,
  // listtile(todoItems라는 리스트 안에 있는 스트링을 listtile에 하나씩 대입)
  Widget _buildToDoItem(String todoText, int index) {
    return Container(
      //width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height*1/18,
      decoration: BoxDecoration(
        //color: Colors.orangeAccent,
        //border: Border.all(color: Colors.white, width: 1)
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(width: 50,),
          Expanded(
            child: Text("${sub1_todo[index]}",
              style: TextStyle(fontSize: 14),
            ),
          ),
          IconButton(
                icon: Icon(Icons.delete_forever),
                onPressed: (){
                  _promptRemoveTodoItem(index);
                }
              ),
        ],
      ),
    );
      //onTap: () => _promptRemoveTodoItem(index),
  }


  _promptRemoveTodoItem(int index) {
    //완료처리(*삭제)
    showDialog(
      //플러터 기본 함수, 다이어로그  보여주는 거
        context: context,
        builder: (BuildContext context) {
        // 알림화면(title, body, actions)
          return new AlertDialog(
            title: new Text(' "${sub1_todo[index]}" 삭제 하시겠습니까?'),
              actions: <Widget>[
                new FlatButton(
                    child: new Text('취소'),
                    onPressed: () => Navigator.of(context).pop()
                ),
                new FlatButton(
                    child: new Text('삭제'),
                    onPressed: () {
                      _removeTodoItem(index);
                      Navigator.of(context).pop();
                    }
                )
              ]
          );
        }
    );
  }

  //list에서 항목 삭제하는 거
  _removeTodoItem(int index) {
    setState(() => sub1_todo.removeAt(index));
  }



  _addTodolistoneItem(String sub){
    //리스트 추가
    showDialog(
      //플러터 기본 함수, 다이어로그  보여주는 거
        context: context,
        builder: (BuildContext context) {
          // 알림화면(title, body, actions)
          return new AlertDialog(
              title: new Text('할 일 추가'),
              content: SingleChildScrollView(
                child: ListBody(
                  children: [
                    Text('$sub'),
                    TextField(
                      controller: _addListControl,
                      decoration: InputDecoration(
                        hintText: '할 일을 입력하세요'
                      ),
                    ),
                  ],
                ),
              ),
              actions: <Widget>[
                new FlatButton(
                    child: new Text('취소'),
                    onPressed: () {
                      _addListControl.text='';
                      Navigator.of(context).pop();
                    }
                ),
                new FlatButton(
                    child: new Text('확인'),
                    onPressed: () {
                      sub1_todo.add(_addListControl.text.trim());
                      _addListControl.text='';
                      Navigator.of(context).pop();
                    }
                )
              ]
          );
        }
    );
  }


  _addSubItem(){
    //과목 추가
    showDialog(
      //플러터 기본 함수, 다이어로그  보여주는 거
        context: context,
        builder: (BuildContext context) {
          // 알림화면(title, body, actions)
          return new AlertDialog(
              title: new Text('과목 추가'),
              content: SingleChildScrollView(
                child: ListBody(
                  children: [
                    TextField(
                      controller: _addSubControl,
                      decoration: InputDecoration(
                          hintText: '과목 이름 입력'
                      ),
                    ),
                  ],
                ),
              ),
              actions: <Widget>[
                new FlatButton(
                    child: new Text('취소'),
                    onPressed: () {
                      _addSubControl.text = '';
                      Navigator.of(context).pop();
                    }
                ),
                new FlatButton(
                    child: new Text('확인'),
                    onPressed: () {
                      sub.add(_addSubControl.text.trim());
                      _addSubControl.text = '';
                      Navigator.of(context).pop();
                    }
                )
              ]
          );
        }
    );
  }

}
