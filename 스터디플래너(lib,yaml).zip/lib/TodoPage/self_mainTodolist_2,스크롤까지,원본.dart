import 'package:flutter/material.dart';
import 'package:planner_todo/main.dart';

class SelfApp_todo extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TODO',
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      home: MyHomePage(title: 'Flutter Todo page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;
  List<String> sub = ["정보처리기사 실기", "영어", "수학", "졸업작품","전공 공부"];
  List<String> sub1_todo = ["정보처리기사 실기 1단원 공부", "1단원 복습", "1단원 정리", "2단원 복습","정보처리기사 실기 2단원 공부"];

  DateTime today = DateTime.now();

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Column(
        children: <Widget>[
          _TopDate(),
          _middlePercent(),
          _bottomTodo(),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }


  Widget _TopDate(){  //날짜 나오는 곳
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget> [
          Text("${today.year}년 ${today.month}월 "
              "${today.day}일", style: TextStyle(fontSize: 20),),
          Row(
            children: [
              IconButton(
                  icon: Icon(Icons.navigate_before),
                  onPressed:(){
                    setState(() {
                      today = today.add(Duration( days: -1));
                    });
                  }
              ),
              SizedBox(width: 10,),
              IconButton(
                  icon: Icon(Icons.navigate_next),
                  onPressed:(){
                    setState(() {
                      today = today.add(Duration( days: 1));
                    });
                  }
              ),
            ],
          ),

        ],
      ),
    );
  }

  Widget _middlePercent(){  //달성도 나오는 곳
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height*1/8,
      color: Colors.deepPurple,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Center(
            child: Column(
              children: <Widget> [
                Text('달성도',
                  style: TextStyle(
                      fontSize: 15,
                      color: Colors.white
                  ),
                ),
                Text('100%',
                  style: TextStyle(
                      fontSize: 40,
                    decoration: TextDecoration.underline,
                    color: Colors.white
                  ),
                ),
              ],
            )
        ),
      ),
    );
  }

  Widget _bottomTodo(){
    return Container(
      //color: Colors.deepOrangeAccent,
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height*5/8,
      child: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            for(int i = 0; i < sub.length ; i++)
              Container(
                child: Column(  //todo 과목별 큰 묶음(1과목+1과목todolist)
                  children: [
                    Container(
                      //width: MediaQuery.of(context).size.width,
                      //height: MediaQuery.of(context).size.height*1/9,
                      decoration: BoxDecoration(
                          //color: Colors.orange,
                          border: Border.all(color: Colors.grey, width: 1)),
                      child: Column(  //todo 과목 라인(반복)
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(    //todo 과목 라인
                              children:[
                                Expanded(
                                  child: Row(    //과목 아이콘이랑 제목
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.all(15.0),
                                        child: Icon(Icons.create),
                                      ),
                                      Center(child: Text(sub[i], style: TextStyle(fontSize: 20),)),
                                    ],
                                  ),
                                ),
                                Row(    //todo 추가할 버튼
                                  children: [
                                    IconButton(
                                        icon: Icon(Icons.add),
                                        onPressed: (){}
                                    ),
                                  ],
                                ),
                              ]
                          ),

                        ],
                      ),

                    ),
                    Column( //todolist
                      children: <Widget> [
                        if(sub[i] == "정보처리기사 실기")
                          _buildToDoList()
                      ],
                    )
                  ],
                ),
              ),

          ],
        ),
      ),
    );
  }

  Widget _buildToDoList() {
    return ListView.separated(
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: sub1_todo.length,
        itemBuilder: (BuildContext context, int index) {
          if(index < sub1_todo.length) {
            return _buildToDoItem(sub1_todo[index], index);
          }
        },
      separatorBuilder: (BuildContext context, int index)
      => const Divider(height: 6, thickness: 2,),
    );
  }

  //_buildtodolist 하단,
  // listtile(todoItems라는 리스트 안에 있는 스트링을 listtile에 하나씩 대입)
  Widget _buildToDoItem(String todoText, int index) {
    return Container(
      //width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height*1/18,
      decoration: BoxDecoration(
        //color: Colors.orangeAccent,
        //border: Border.all(color: Colors.white, width: 1)
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(width: 50,),
          Text("${sub1_todo[index]}",
            style: TextStyle(fontSize: 14),),
        ],
      ),
    );
      //onTap: () => _promptRemoveTodoItem(index),
  }


  _promptRemoveTodoItem(int index) {
    //완료처리(*삭제)
    showDialog(
      //플러터 기본 함수, 다이어로그  보여주는 거
        context: context,
        builder: (BuildContext context) {

          return new AlertDialog(
            //알림화면(title, body, actions)
              title: new Text(' "${sub1_todo[index]}" 완료 처리 하시겠습니까?'),
              actions: <Widget>[
                new FlatButton(
                    child: new Text('CANCEL'),
                    onPressed: () => Navigator.of(context).pop()
                ),
                new FlatButton(
                    child: new Text('완료'),
                    onPressed: () {
                      _removeTodoItem(index);
                      Navigator.of(context).pop();
                    }
                )
              ]
          );
        }
    );
  }

  //list에서 항목 삭제하는 거
  _removeTodoItem(int index) {
    setState(() => sub1_todo.removeAt(index));
  }


}
