import 'package:date_picker_timeline/date_picker_timeline.dart';
import 'package:flutter/material.dart';


class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Todo list',
      theme: ThemeData(
        primarySwatch: Colors.lightGreen,
      ),
      home: MyHomePage(title: 'Flutter Todo list'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  DatePickerController _controller = DatePickerController();

  DateTime _selectedValue = DateTime.now();


  @override
  void initState() {
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Column(
        children: <Widget>[
          _TopDate(),
          _middlePercent(),
          _bottomTodo(),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _controller.animateToSelection();
        },
        child: Icon(Icons.replay),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }


  Widget _TopDate(){
    return Container(
          padding: EdgeInsets.all(20.0),
          color: Colors.blueGrey[100],
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(_selectedValue.toString()),
              Container(
                child: DatePicker(
                  DateTime(DateTime.now().year, DateTime.now().month-2, 1),
                  locale: "ko_KR",
                  width: 70,  //원래 60,80이었고 한글로 바꾸니까 깨져서 70 85함
                  height: 85,
                  controller: _controller,
                  initialSelectedDate: DateTime.now(),  //맨처음에 체크 돼 있는 거 , 지우면 체크 안돼있음
                  selectionColor: Colors.black,
                  selectedTextColor: Colors.white,
                  /*inactiveDates: [
                    DateTime.now().add(Duration(days: 3)),
                    DateTime.now().add(Duration(days: 4)),
                    DateTime.now().add(Duration(days: 7))
                  ],*/
                  onDateChange: (date) {
                    // New date selected
                    setState(() {
                      _selectedValue = date;
                    });
                  },
                  //daysCount: 5, //5개씩만 나오게 하는 거
                ),
              ),
            ],
          ),
        );
  }

  Widget _middlePercent(){
    return Text('middle');
  }

  Widget _bottomTodo(){
    return Text('bottom');
  }

}