import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:planner_todo/TodoPage/self_addTodolist,3,db%EC%97%B0%EA%B2%B0.dart';



DateTime today = DateTime.now();
DocumentSnapshot doc;
User _user = FirebaseAuth.instance.currentUser;

class PercentProvider with ChangeNotifier{
  /*
  getNewPercent(DateTime dateTime) => todoReturnFun(dateTime);

  String todoReturnFun(DateTime day){
    todoPercentageProvider(day);
    return this._percent;
  }
*/
  DateTime today = DateTime.now();
  String _percent = null;
  int _percentInt = 0;

  getPercent() => _percent;
  getIntPercent() => _percentInt;

  Future<int> todoPercentageVoidProvider(DateTime today) async {
    String todayDate = DateFormat('yyyyMMdd').format(today);

    final QuerySnapshot todayAllResult =
    await FirebaseFirestore.instance.collection('Todolist')
        .doc(_user.uid).collection('Todo').doc('date')
        .collection(todayDate)
        .get();

    final QuerySnapshot todayDoneResult =
    await FirebaseFirestore.instance.collection('Todolist')
        .doc(_user.uid).collection('Todo').doc('date')
        .collection(todayDate).where('isDone', isEqualTo: true)
        .get();

    final QuerySnapshot percentDB =
        await FirebaseFirestore.instance.collection('Todolist')
            .doc(_user.uid).collection('Todo').doc('date')
            .collection('Percent').where('date', isEqualTo: todayDate).get();

    final List<DocumentSnapshot> todayDoneDocuments = todayDoneResult.docs;
    final List<DocumentSnapshot> todayAllDocuments = todayAllResult.docs;
    final List<DocumentSnapshot> percentDocuments = percentDB.docs;

    if(todayAllDocuments.length == 0){
      this._percentInt = 0;
    } else {
      var _tileCount = todayDoneDocuments.length;
      double cal = _tileCount / (todayAllDocuments.length);
      this._percentInt = (cal * 100.floor()).toInt();
    }

    if(this._percentInt == 0) {

    } else {
      if(percentDocuments.length == 0){
        await FirebaseFirestore.instance.collection('Todolist')
            .doc(_user.uid).collection('Todo').doc('date')
            .collection('Percent').add({
          'date' : todayDate,
          'Percent' : this._percentInt
        });
      } else {
        await FirebaseFirestore.instance.collection('Todolist')
            .doc(_user.uid).collection('Todo').doc('date')
            .collection('Percent').doc().update({
          'date' : todayDate,
          'Percent' : this._percentInt
        });
      }
    }

    notifyListeners();
    return _percentInt;
  }//데이터구조수정후23번

//색깔 넣어주려면 Double형 가져오는 걸로 새로 하나 선언해주기(고쳐야 됨.)
  Future<int> todoPercentageIntProvider(DateTime today) async {
    String todayDate = DateFormat('yyyyMMdd').format(today);

    final QuerySnapshot todayAllResult =
    await FirebaseFirestore.instance.collection('Todolist')
        .doc(_user.uid).collection('Todo').doc('date')
        .collection(todayDate)
        .get();

    final QuerySnapshot todayDoneResult =
    await FirebaseFirestore.instance.collection('Todolist')
        .doc(_user.uid).collection('Todo').doc('date')
        .collection(todayDate).where('isDone', isEqualTo: true)
        .get();


    final List<DocumentSnapshot> todayDoneDocuments = todayDoneResult.docs;
    final List<DocumentSnapshot> todayAllDocuments = todayAllResult.docs;

    if(todayAllDocuments.length == 0){
      this._percentInt = 0;
    } else {
      var _tileCount = todayDoneDocuments.length;
      double cal = _tileCount / (todayAllDocuments.length);
      this._percentInt = (cal * 100.floor()).toInt();
    }
    notifyListeners();
    return _percentInt;
  }//데이터구조수정후23번



  Future<String> todoPercentageProvider(DateTime today) async {
    String todayDate = DateFormat('yyyyMMdd').format(today);

    final QuerySnapshot todayAllResult =
    await FirebaseFirestore.instance.collection('Todolist')
        .doc(_user.uid).collection('Todo').doc('date')
        .collection(todayDate)
        .get();

    final QuerySnapshot todayDoneResult =
    await FirebaseFirestore.instance.collection('Todolist')
        .doc(_user.uid).collection('Todo').doc('date')
        .collection(todayDate).where('isDone', isEqualTo: true)
        .get();


    final List<DocumentSnapshot> todayDoneDocuments = todayDoneResult.docs;
    final List<DocumentSnapshot> todayAllDocuments = todayAllResult.docs;

    if(todayAllDocuments.length == 0){
      this._percent = null;
    } else {
      var _tileCount = todayDoneDocuments.length;
      double cal = _tileCount / (todayAllDocuments.length);
      this._percent = (cal * 100.floor()).toInt().toString();
    }

    notifyListeners();
    return this._percent;
  }//데이터구조수정후23번

  //todomaping은 참고용
  Future<void> todoMaping(DateTime today) async {
    String todayDate = DateFormat('yyyyMMdd').format(today);

    final QuerySnapshot todoAll =
        await FirebaseFirestore.instance.collection('Todolist')
        .doc(_user.uid).collection('Todo').doc('date')
        .collection(todayDate).get();

    final QuerySnapshot todoIsDone =
    await FirebaseFirestore.instance.collection('Todolist')
        .doc(_user.uid).collection('Todo').doc('date')
        .collection(todayDate).get();

    final QuerySnapshot percentY =
    await FirebaseFirestore.instance.collection('Todolist')
        .doc(_user.uid).collection('Percent')
        .where('date', isEqualTo: todayDate).get();

    final List<DocumentSnapshot> todoAllDocs = todoAll.docs;
    final List<DocumentSnapshot> todoIsDoneDocs = todoIsDone.docs;
    final List<DocumentSnapshot> percentYDocs = percentY.docs;

    if(todoAllDocs.length != 0){
      if(percentYDocs.length != 0){
        //update
        FirebaseFirestore.instance.collection('Todolist')
            .doc(_user.uid).collection('Percent')
            .doc(doc.id).update({
          'date' : todayDate,
          'percentage' : _percent
        });
      } else {
        //add
        FirebaseFirestore.instance.collection('Todolist')
            .doc(_user.uid).collection('Percent').add({
          'date' : todayDate,
          'percentage' : _percent
        });
      }
    }
    //map구조
    FirebaseFirestore.instance.collection('Todolist')
        .doc(_user.uid).collection('Percent').add({
      'percentage' : {todayDate : _percent}
    });
    notifyListeners();

  }



  /**
  Future<String> todoPercentageProvider(DateTime today) async {
    String todayDate = DateFormat('yyyyMMdd').format(today);

    final QuerySnapshot todayAllResult =
    await FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo')
        .where('date', isEqualTo: todayDate)
        .get();

    final QuerySnapshot todayDoneResult =
    await FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo')
        .where('date', isEqualTo: todayDate)
        .where('isDone', isEqualTo: true).get();

    final List<DocumentSnapshot> todayDoneDocuments = todayDoneResult.docs;
    final List<DocumentSnapshot> todayAllDocuments = todayAllResult.docs;

    if(todayAllDocuments.length == 0){
      _percent = '0';
    } else {
      var _tileCount = todayDoneDocuments.length;
      double cal = _tileCount / (todayAllDocuments.length);
      _percent = (cal * 100.floor()).toInt().toString();
    }


    notifyListeners();
    return _percent;
  }
      21번, 22번
  **/


  /**
  Future<String> todoPercentageProvider() async {
    String todayDate = DateFormat('yyyyMMdd').format(today);

    final QuerySnapshot todayAllResult =
    await FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo')
        .where('date', isEqualTo: todayDate)
        .get();

    final QuerySnapshot todayDoneResult =
    await FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo')
        .where('date', isEqualTo: todayDate)
        .where('isDone', isEqualTo: true).get();

    final List<DocumentSnapshot> todayDoneDocuments = todayDoneResult.docs;
    final List<DocumentSnapshot> todayAllDocuments = todayAllResult.docs;

    if(todayAllDocuments.length == 0){
      _percent = '0';
    } else {
      var _tileCount = todayDoneDocuments.length;
      double cal = _tileCount / (todayAllDocuments.length);
      _percent = (cal * 100.floor()).toInt().toString();
    }
    notifyListeners();
    return _percent;

  }
   //20번 함수엔 인스턴스 없음
   **/
}


