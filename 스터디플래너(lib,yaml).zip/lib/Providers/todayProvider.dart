import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class TodayProvider with ChangeNotifier {
  DateTime today = DateTime.now();

  String todayStr;
  String todayDate;

  getToday() => today;
  setTodayString() => todayStr = DateFormat('yyyy년 MM월 dd일').format(getToday());
  setTodayDate() => todayDate = DateFormat('yyyyMMdd').format(getToday());
  //setCounter(int counter) => _counter = counter;


  void increment() {
    today = today.add(Duration( days: 1));
    notifyListeners(); // 값이 변할 때마다 플러터 프레임워크에 알려줍니다.
  }

  void decrement() {
    today = today.add(Duration( days: -1));
    notifyListeners(); // 값이 변할 때마다 플러터 프레임워크에 알려줍니다.
  }
}
