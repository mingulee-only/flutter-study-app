
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_platform_widgets/flutter_platform_widgets.dart';
import 'package:planner_todo/DiaryPage/view/main_page.dart';

final materialThemeData = ThemeData(
    primarySwatch: Colors.blue,
    scaffoldBackgroundColor: Colors.white,
    accentColor: Colors.blue,
    appBarTheme: AppBarTheme(color: Colors.blue.shade600),
    primaryColor: Colors.blue,
    secondaryHeaderColor: Colors.blue,
    canvasColor: Colors.blue,
    backgroundColor: Colors.red,
    textTheme: TextTheme().copyWith(bodyText2: TextTheme().bodyText2));

final cupertinoTheme = CupertinoThemeData(
    primaryColor: Colors.blue,
    barBackgroundColor: Colors.blue,
    scaffoldBackgroundColor: Colors.white);

/*
void main() {
  runApp(PlatformApp(
    debugShowCheckedModeBanner: false,
    home: MainPage(),
    title: 'Diary Application',
  ));
}
*/

Widget mainDiaryPage(){
  return PlatformApp(
    debugShowCheckedModeBanner: false,
    home: MainPage(),
    title: 'Diary Application',
  );
}
