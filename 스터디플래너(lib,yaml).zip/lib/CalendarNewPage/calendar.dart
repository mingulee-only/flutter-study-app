
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:planner_todo/Providers/percentProvider.dart';
import 'package:provider/provider.dart';
import 'package:table_calendar/table_calendar.dart';

import 'event.dart';

class CalendarPage extends StatefulWidget {
  @override
  _CalendarState createState() => _CalendarState();
}

class _CalendarState extends State<CalendarPage> {
  Map<DateTime, List<int>> selectedPercents;
  Map<DateTime, List<Event>> selectedEvents;
  CalendarFormat format = CalendarFormat.month;
  final ValueNotifier<DateTime> _focusedDay = ValueNotifier(DateTime.now());
  DateTime today = DateTime.now();
  DateTime selectedDay = DateTime.now();
  DateTime focusedDay = DateTime.now();

  TextEditingController _eventController = TextEditingController();
  PercentProvider percentProvider;

  @override
  void initState() {
    selectedPercents = {};
    selectedEvents = {};
    super.initState();
    //Provider.of<PercentProvider>(context, listen: false).todoPercentageVoidProvider(selectedDay);
  }

  List<Event> _getEventsfromDay(DateTime date) {
    return selectedEvents[date] ?? [];
  }

  List<int> _getPercentsfromDay(DateTime date) {
    //percentProvider.todoPercentageProvider(date);

    if(percentProvider.getIntPercent() == 0){
      selectedPercents[date] = [0];
    } else {
      selectedPercents[date] = [percentProvider.getIntPercent()];
    }

    //selectedPercents[date] = [percentProvider.getPercent()];
    //방법 1) 이렇게만 실행하면 마커 계속 들어가 있음
    return selectedPercents[date] ?? [];
  }

  /*
  //int형
  List<int> _getPercentsfromDay(DateTime date){
    //percentProvider.todoPercentageProvider(date);

    if(percentProvider.getIntPercent() == 0){
      selectedPercents[date] = [0];
    } else {
      selectedPercents[date] = [await percentProvider.getIntPercent()];
    }

    //selectedPercents[date] = [percentProvider.getPercent()];
    //방법 1) 이렇게만 실행하면 마커 계속 들어가 있음
    return selectedPercents[date] ?? [];
  }

*/
  /*
  //이렇게 하면 하루에 달성도가 0이랑 해당 당일 달성도 번갈아서 계속 들어갔다 안들어갔다 하는 느낌
  List<String> _getPercentsfromDay(DateTime date){
    percentProvider.todoPercentageProvider(date);
    selectedPercents[date] = [percentProvider.getPercent()];
    return selectedPercents[date];
  }

   */

  @override
  void dispose() {
    _eventController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    percentProvider = Provider.of<PercentProvider>(context);

  //얘를 설정하면 날짜가 안 넘어가는 듯

    setState(() {
      percentProvider.todoPercentageIntProvider(selectedDay);
      //percentProvider.todoPercentageVoidProvider(selectedDay);
    });

    return Scaffold(
      /*appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text("ESTech Calendar"),
        centerTitle: true,
      ),*/
      body: SingleChildScrollView(
        child: Column(
          children: [
            /*
            ValueListenableBuilder<DateTime>(
              valueListenable: _focusedDay,
              builder: (context, value, _) {
                return _CalendarHeader(
                  focusedDay: value,


                  //오늘로 돌아오는 코드
                  onTodayButtonTap: () {
                    setState(() => _focusedDay.value = DateTime.now());
                  },


                  onLeftArrowTap: () {
                    _pageController.previousPage(
                      duration: Duration(milliseconds: 300),
                      curve: Curves.easeOut,
                    );
                  },
                  onRightArrowTap: () {
                    _pageController.nextPage(
                      duration: Duration(milliseconds: 300),
                      curve: Curves.easeOut,
                    );
                  },
                );
              },
            ),*/
            TableCalendar<int>(
              //페이지 넘어가게 하는 거(해당 달의 1일로 셀렉됨)
              onPageChanged: (focusedDate){
                selectedDay = focusedDate;
              },

              rowHeight: 55,

              //요일 높이
              daysOfWeekHeight: 25,
              //한글 설정
              locale: 'ko-KR',
              focusedDay: selectedDay,
              firstDay: DateTime(1990),
              lastDay: DateTime(2050),
              headerVisible: true,
              availableCalendarFormats: const {CalendarFormat.month : 'Today',
                CalendarFormat.twoWeeks : 'toto'},

              ///원래 format 버튼인데 내맘대로 today로 바꿈
              calendarFormat: format,
              onFormatChanged: (CalendarFormat _format) {
                setState(() {
                  selectedDay = DateTime.now();
                });
              },

              startingDayOfWeek: StartingDayOfWeek.sunday,
              //daysOfWeekVisible: true,

              //Day Changed
              onDaySelected: (DateTime selectDay, DateTime focusDay) {
                setState(() {
                  selectedDay = selectDay;
                  focusedDay = focusDay;
                  //percentProvider.todoPercentageProvider(selectedDay);
                });
                print(focusedDay);
              },
              selectedDayPredicate: (DateTime date) {
                return isSameDay(selectedDay, date);
              },

              holidayPredicate: (day){
                return day.day == 10;
              },

              eventLoader: (DateTime date){
                //percentProvider.todoPercentageProvider(date);
                return _getPercentsfromDay(date);
                /*
                if(percentProvider.getPercent() != null){
                  //null 아닐 때만 실행하면 null 일 때도 계속 마커 켜짐...
                  return _getPercentsfromDay(date);
                } else {
                  return _getPercentsfromDay(date);
                }*/
              },
                //To style the Calendar
                calendarStyle: CalendarStyle(

                isTodayHighlighted: true,

                //일정 있을 때 표시
                markersAnchor: 0.8,
                markerSize: 15,
                markerDecoration:
                //그 날짜 마커만 색을 바꿀 순 없나???
                percentProvider.getIntPercent() >= 75 ?
                BoxDecoration(
                // ignore: unrelated_type_equality_checks
                color: Colors.deepOrange,
                shape: BoxShape.circle,
                ) : BoxDecoration(
                // ignore: unrelated_type_equality_checks
                color: Colors.blue,
                shape: BoxShape.circle,
                ),


                //default = 평일
                defaultDecoration: BoxDecoration(
                shape: BoxShape.rectangle,
                borderRadius: BorderRadius.circular(5.0),
                ),
                defaultTextStyle: TextStyle(color: Colors.black),

                //selected 선택한 날짜
                selectedDecoration: BoxDecoration(
                  border: Border.fromBorderSide(
                      BorderSide(
                          color: Colors.lightGreen,
                          width: 2.5
                      )
                  ),
                  shape: BoxShape.rectangle,
                  borderRadius: BorderRadius.circular(5.0),
                ),

                  selectedTextStyle: TextStyle(color: Colors.black),

                  //today 오늘
                  todayDecoration: BoxDecoration(
                      border: Border.fromBorderSide(
                          BorderSide(
                              color: Colors.yellow[800],
                              width: 3
                          )
                      ),
                      shape: BoxShape.rectangle,
                      borderRadius: BorderRadius.circular(5.0),
                  ),

                  todayTextStyle: TextStyle(color: Colors.black87),
                  //주말
                  weekendDecoration: BoxDecoration(
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.circular(5.0),
                  ),
                  weekendTextStyle: TextStyle(color: Colors.black54),


                  holidayTextStyle: TextStyle(color:Colors.deepOrange),
                  holidayDecoration: BoxDecoration(
                  border: Border.fromBorderSide(
                  BorderSide(
                      color: Colors.red,
                      width: 1.4
                    )
                  ),
                  shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.circular(5.0),
                ),

              ),
              headerStyle: HeaderStyle(
                titleCentered: true,

                //먼스 버튼
                formatButtonVisible: true,
                formatButtonShowsNext: false,

                /*
                formatButtonDecoration: BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.circular(5.0),
                ),
                formatButtonTextStyle: TextStyle(
                  color: Colors.white,
                ),
                */

              ),
            ),
             //[] 안에 selectedDay 넣게 되면 today 누르면 null값 들어감
            Text('달성도 ${selectedPercents[selectedDay]} %'),
             Text('달성도 ${selectedPercents[focusedDay]} %'),
             //달성도 있는 거 누른 후에 null값 인 곳 누르면 이전 달성도 들어가있음
             Text('달성도 ${percentProvider.getIntPercent()} %'),

             //일정 목록 나오는 것
            ..._getEventsfromDay(selectedDay).map(
              (Event event) => ListTile(
                title: Text(
                  event.percent,
                ),
              ),
            ),
          ],
        ),
      ),


      ///add event
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text("Add Event"),
            content: TextFormField(
              controller: _eventController,
            ),
            actions: [
              TextButton(
                child: Text("Cancel"),
                onPressed: () => Navigator.pop(context),
              ),
              TextButton(
                child: Text("Ok"),
                onPressed: () {
                  if (_eventController.text.isEmpty) {
                    selectedPercents[selectedDay].add(
                      percentProvider.getIntPercent(),
                    );
                  } else {
                    if (selectedPercents[selectedDay] != null) {
                      selectedPercents[selectedDay].add(
                        percentProvider.getIntPercent(),
                      );
                    } else {
                      selectedPercents[selectedDay] = [
                        percentProvider.getIntPercent(),
                        //Event(percent: _eventController.text)
                      ];
                    }

                  }
                  Navigator.pop(context);
                  _eventController.clear();
                  setState((){});
                  return;
                },
              ),
            ],
          ),
        ),
        label: Text("Add Event"),
        icon: Icon(Icons.add),
      ),
    );
  }
}

/*
class _CalendarHeader extends StatelessWidget {
  final DateTime focusedDay;
  final VoidCallback onLeftArrowTap;
  final VoidCallback onRightArrowTap;
  final VoidCallback onTodayButtonTap;
  final VoidCallback onClearButtonTap;
  final bool clearButtonVisible;

  const _CalendarHeader({
    Key key,
    @required this.focusedDay,
    @required this.onLeftArrowTap,
    @required this.onRightArrowTap,
    @required this.onTodayButtonTap,
    @required this.onClearButtonTap,
    @required this.clearButtonVisible,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final headerText = DateFormat.yMMM().format(focusedDay);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          const SizedBox(width: 16.0),
          SizedBox(
            width: 120.0,
            child: Text(
              headerText,
              style: TextStyle(fontSize: 26.0),
            ),
          ),
          IconButton(
            icon: Icon(Icons.calendar_today, size: 20.0),
            visualDensity: VisualDensity.compact,
            onPressed: onTodayButtonTap,
          ),
          const Spacer(),
          IconButton(
            icon: Icon(Icons.chevron_left),
            onPressed: onLeftArrowTap,
          ),
          IconButton(
            icon: Icon(Icons.chevron_right),
            onPressed: onRightArrowTap,
          ),
        ],
      ),
    );
  }
}*/