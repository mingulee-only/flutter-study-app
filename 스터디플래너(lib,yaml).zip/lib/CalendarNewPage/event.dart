import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:intl/intl.dart';

class Event {
  final String percent;

  Event({@required this.percent});

  String toString() => this.percent;

}
