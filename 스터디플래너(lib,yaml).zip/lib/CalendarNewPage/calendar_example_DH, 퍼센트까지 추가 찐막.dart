import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_file.dart';
import 'package:intl/intl.dart';
import 'package:planner_todo/Providers/percentProvider.dart';
import 'package:planner_todo/TodoPage/self_addTodolist,3,db%EC%97%B0%EA%B2%B0.dart';
import 'package:provider/provider.dart';
import 'package:table_calendar/table_calendar.dart';

class CalendarExample extends StatefulWidget {
  @override
  _CalendarExampleState createState() => _CalendarExampleState();
}

class _CalendarExampleState extends State<CalendarExample> {
  CalendarFormat _calendarFormat = CalendarFormat.month;
  List<int> _eventTitleList = [];
  int p;
  List<Color> colorsRed = [Colors.red[700], Colors.red[500],
  Colors.red[300], Colors.red[100]];



  @override
  void initState() {
    super.initState();
    Provider.of<CalendarDataViewModel>(context, listen: false).initDate();
  }

  Widget _buildEventMarker(DateTime date, List<dynamic> events, Map<DateTime, List<int>> selectDateList){
    Widget wid;

    DateTime getDate(DateTime time) {
      return DateTime(time.year, time.month, time.day);
    }
    //events.forEach((element) {print(events[0]);});
    //이거 하면 날짜 나옴
    //events[0] == getDate(DateTime.now()) 이거 넣으면 원하는 날짜의 마커 색 바꿀 수 있음

    if(events.isEmpty){

    } else {
      if(selectDateList[getDate(date)][0] == 100){
        wid = Container(
          width: 15,
          height: 15,
          decoration: BoxDecoration(
            // ignore: unrelated_type_equality_checks
            color: colorsRed[0],
            shape: BoxShape.circle,
          ),
        );
      } else if (selectDateList[getDate(date)][0] > 80){
        wid = Container(
          width: 15,
          height: 15,
          decoration: BoxDecoration(
            // ignore: unrelated_type_equality_checks
            color: colorsRed[1],
            shape: BoxShape.circle,
          ),
        );
      } else if (selectDateList[getDate(date)][0] > 40){
        wid = Container(
          width: 15,
          height: 15,
          decoration: BoxDecoration(
            // ignore: unrelated_type_equality_checks
            color: colorsRed[2],
            shape: BoxShape.circle,
          ),
        );
      } else if (selectDateList[getDate(date)][0] > 0){
        wid = Container(
          width: 15,
          height: 15,
          decoration: BoxDecoration(
            // ignore: unrelated_type_equa
            // lity_checks
            color: colorsRed[3],
            shape: BoxShape.circle,
          ),
        );
      } else {

      }

    }

    return wid;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Consumer<CalendarDataViewModel>(
        builder: (_, viewModel, __) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TableCalendar(
                availableCalendarFormats: const {CalendarFormat.month : 'Today',
                CalendarFormat.twoWeeks : 'Today2'},

                calendarFormat: _calendarFormat,
                onFormatChanged: (CalendarFormat _format) {
                  setState(() {
                    viewModel.model.focusedDay = DateTime.now();
                  });
                },

                //요일 높이
                daysOfWeekHeight: 25,
                //한글 설정
                locale: 'ko-KR',
                firstDay: DateTime(2021, 4, 1),
                lastDay: DateTime(2040, 5, 1),
                focusedDay: viewModel.model.focusedDay,

                eventLoader: (day) {
                  return viewModel.getEventDaysList(day);
                },
                selectedDayPredicate: (day) {
                  return isSameDay(viewModel.model.selectedDay, day);
                },
                onDaySelected: (selectedDay, focusedDay) {
                  if (!isSameDay(viewModel.model.selectedDay, selectedDay)) {
                    viewModel.setSelectedDays(selectedDay, focusedDay);
                    _eventTitleList = viewModel.getSelectedDayList(selectedDay);
                  } //여기서 eventTitlelist에 달성도(일정리스트) 받아와서
                },

                onPageChanged: (focusedDay) {
                  viewModel.model.focusedDay = focusedDay;
                },

                headerStyle: HeaderStyle(
                  //titleCentered: true,
                  titleTextStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),

                  //먼스 버튼
                  formatButtonVisible: true,
                  formatButtonShowsNext: false,

                  /*
                formatButtonDecoration: BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.circular(5.0),
                ),
                formatButtonTextStyle: TextStyle(
                  color: Colors.white,
                ),
                */

                ),
                calendarBuilders: CalendarBuilders(
                  markerBuilder: (context, day, events) {
                    Widget markerWidget;
                    if(events.isNotEmpty ){
                      markerWidget = Positioned(
                        child: _buildEventMarker(day, events, viewModel.model.selectedDayList),
                      );
                    }
                    return markerWidget;
                  },
                ),
                calendarStyle: CalendarStyle(
                  outsideDaysVisible: false,

                  isTodayHighlighted: true,

                  //일정 있을 때 표시
                  markersAnchor: 0.8,
                  markerSize: 15,


    /*

                  markerDecoration:
                  //그 날짜 마커만 색을 바꿀 순 없나???


                  _eventTitleList[0] >= 85 ?
                  BoxDecoration(
                    // ignore: unrelated_type_equality_checks
                    color: Colors.deepOrange,
                    shape: BoxShape.circle,
                  ) : BoxDecoration(
                    // ignore: unrelated_type_equality_checks
                    color: Colors.blue,
                    shape: BoxShape.circle,
                  ),
*/

                  //default = 평일
                  defaultDecoration: BoxDecoration(
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.circular(5.0),
                  ),
                  defaultTextStyle: TextStyle(color: Colors.black),

                  //selected 선택한 날짜
                  selectedDecoration: BoxDecoration(
                    border: Border.fromBorderSide(
                        BorderSide(
                            color: Colors.lightGreen,
                            width: 2.5
                        )
                    ),
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.circular(5.0),
                  ),

                  selectedTextStyle: TextStyle(color: Colors.black),

                  //today 오늘
                  todayDecoration: BoxDecoration(
                    border: Border.fromBorderSide(
                        BorderSide(
                            color: Colors.yellow[800],
                            width: 3
                        )
                    ),
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.circular(5.0),
                  ),

                  todayTextStyle: TextStyle(color: Colors.black87),
                  //주말
                  weekendDecoration: BoxDecoration(
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.circular(5.0),
                  ),
                  weekendTextStyle: TextStyle(color: Colors.black54),


                  holidayTextStyle: TextStyle(color:Colors.deepOrange),
                  holidayDecoration: BoxDecoration(
                    border: Border.fromBorderSide(
                        BorderSide(
                            color: Colors.red,
                            width: 1.4
                        )
                    ),
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.circular(5.0),
                  ),

                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  height: 40,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.circle,
                      color: colorsRed[0], size: 10,),
                      Text("\t100%\t\t"),
                      SizedBox(width: 10,),
                      Icon(Icons.circle,
                        color: colorsRed[1], size: 10,),
                      Text("\t80~99%\t\t"),
                      SizedBox(width: 10,),
                      Icon(Icons.circle,
                        color: colorsRed[2], size: 10,),
                      Text("\t41~79%\t\t"),
                      SizedBox(width: 10,),
                      Icon(Icons.circle,
                        color: colorsRed[3], size: 10,),
                      Text("\t1%~40%\t\t"),
                    ],
                  ),
                ),
              ),

              _eventTitleList.isEmpty //여기서 출력
                  ? Container()
                  : ListView.builder(
                      shrinkWrap: true,
                      itemCount: _eventTitleList.length,
                      itemBuilder: (_, index) {
                        int text = _eventTitleList[index];
                        return Card(
                            child: ListTile(
                                title: Center(
                                  child: Text(
                                      "오늘의 달성도 \t" + text.toString() + "%"
                                  ),
                                )
                            )
                        );
                      }),
              /*
              Text(FirebaseFirestore.instance.collection('Todolist')
              .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo').doc('date').collection(todayDate).id),
            */
            ],
          );
        },
      ),
    );
  }
}

class CalendarDataModel {
  DateTime focusedDay = DateTime.now();
  DateTime selectedDay = DateTime.now();
  Map<DateTime, List<int>> selectedDayList;

  CalendarDataModel({this.focusedDay, this.selectedDay, this.selectedDayList});
}

class CalendarDataViewModel extends ChangeNotifier {
  CalendarDataModel model = CalendarDataModel();
  int percent = 99; //얘랑

  void initDate() {
    DateTime oldDate = DateTime(2020,5,1);
    DateTime currentTime = DateTime.now();
    model.focusedDay = currentTime;
    model.selectedDayList = {
      getDate(oldDate): [11],
      //getDate(currentTime.add(Duration(days: 2))): [67, 27],
      //getDate(currentTime.add(Duration(days: 5))): [27],
      /*
      getDate(currentTime.add(Duration(days: 4))):
      [percent = await todoPercentageIntProvider(
          getDate(currentTime.add(Duration(days: 4))))],*/
    };
    //addListPercent(currentTime);
  }

  void addListPercent(DateTime dateTime) async{
    int p = await todoPercentageIntProvider(dateTime);

    if(p == 0){

    } else {
      model.selectedDayList[getDate(dateTime)] = [p];
    }

  }

//색깔 넣어줄 거
  Future<int> todoPercentageIntProvider(DateTime today) async {
    String todayDate = DateFormat('yyyyMMdd').format(today);
    //1
    final QuerySnapshot todayAllResult =
    await FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo').doc('date')
        .collection(todayDate)
        .get();

    //2
    final QuerySnapshot todayDoneResult =
    await FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo').doc('date')
        .collection(todayDate).where('isDone', isEqualTo: true)
        .get();


    final List<DocumentSnapshot> todayDoneDocuments = todayDoneResult.docs;
    final List<DocumentSnapshot> todayAllDocuments = todayAllResult.docs;

    if(todayAllDocuments.length == 0){
      percent = 0;
    } else {
      var _tileCount = todayDoneDocuments.length;
      double cal = _tileCount / (todayAllDocuments.length);
      percent = (cal * 100.floor()).toInt();
    }
    notifyListeners();
    return percent;
  }//데이터구조수정후23번


  void setSelectedDays(DateTime sDay, DateTime fDay) {
    model.selectedDay = sDay;
    model.focusedDay = fDay;
    notifyListeners();
  }

  //해당 날짜 리스트 가져오기(리스트 출력)
  List<int> getSelectedDayList(DateTime dateTime) {
    DateTime day = getDate(dateTime);

    if (model.selectedDayList[day] == null) {
      return [];
    } else {
      return model.selectedDayList[day];
    }
  }

  DateTime getDate(DateTime time) {
    return DateTime(time.year, time.month, time.day);
  }

  List<dynamic> getEventDaysList(DateTime dateTime) {
    DateTime day = getDate(dateTime);
    //print(model.selectedDayList.keys);

    List eventList = [];
    //model.selectedDayList.keys.toList().forEach((element) {print(element);});

    addListPercent(dateTime);

    if (model.selectedDayList.keys.contains(day)) {
      eventList.add(day);
    } else {

    }
    return eventList;
  }
}
