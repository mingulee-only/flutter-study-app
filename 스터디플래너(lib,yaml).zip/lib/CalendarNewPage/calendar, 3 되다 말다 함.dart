
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:planner_todo/Providers/percentProvider.dart';
import 'package:provider/provider.dart';
import 'package:table_calendar/table_calendar.dart';

import 'event.dart';

class Calendar extends StatefulWidget {
  @override
  _CalendarState createState() => _CalendarState();
}

class _CalendarState extends State<Calendar> {
  Map<DateTime, List<String>> selectedPercents;
  Map<DateTime, List<Event>> selectedEvents;
  CalendarFormat format = CalendarFormat.month;
  DateTime selectedDay = DateTime.now();
  DateTime focusedDay = DateTime.now();

  TextEditingController _eventController = TextEditingController();
  PercentProvider percentProvider;

  @override
  void initState() {
    selectedPercents = {};
    selectedEvents = {};
    super.initState();
  }

  List<Event> _getEventsfromDay(DateTime date) {
    return selectedEvents[date] ?? [];
  }

  List<String> _getPercentsfromDay(DateTime date){
    //percentProvider.todoPercentageProvider(date);
    //selectedPercents[date] = [percentProvider.getPercent()];

    return selectedPercents[date];
  }

  /*
  //이렇게 하고 setstate에 percentProvider.todoPercentageProvider(selectedDate)
  //하면, 모든 날짜에 일정이 들어감.
  + 달이 안넘어감,, 왜지?

  //eventLoader:(DateTime date){
  //              if(percentProvider.getPercent() != null){
  //                return _getPercentsfromDay(date);
  //              } else {
  //                return null;
  //              }
  //             },

  //그래서 setstate에 있던 걸 지우고,
  //onDaySelected에 넣었더니 누르는 날짜에 따라서 같은 값이 전체에 들어감....

  List<String> _getPercentsfromDay(DateTime date){
    //percentProvider.todoPercentageProvider(date);
    selectedPercents[date] = [percentProvider.getPercent()];

    return selectedPercents[date];
  }
  */

  /*
  //이렇게 하면 하루에 달성도가 0이랑 해당 당일 달성도 번갈아서 계속 들어갔다 안들어갔다 하는 느낌
  List<String> _getPercentsfromDay(DateTime date){
    percentProvider.todoPercentageProvider(date);
    selectedPercents[date] = [percentProvider.getPercent()];
    return selectedPercents[date];
  }

   */

  @override
  void dispose() {
    _eventController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    percentProvider = Provider.of<PercentProvider>(context);


    setState(() {
      percentProvider.todoPercentageProvider(focusedDay);
    });

    return Scaffold(
      /*appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text("ESTech Calendar"),
        centerTitle: true,
      ),*/
      body: Column(
        children: [
          TableCalendar(
            rowHeight: 55,

            //요일 높이
            daysOfWeekHeight: 25,
            //한글 설정
            locale: 'ko-KR',
            focusedDay: selectedDay,
            firstDay: DateTime(1990),
            lastDay: DateTime(2050),

            availableCalendarFormats: const {CalendarFormat.month : 'Today',
              CalendarFormat.twoWeeks : 'toto'},

            ///원래 format 버튼인데 내맘대로 today로 바꿈
            calendarFormat: format,
            onFormatChanged: (CalendarFormat _format) {
              setState(() {
                setState(() => selectedDay = DateTime.now());
              });
            },

            startingDayOfWeek: StartingDayOfWeek.sunday,
            //daysOfWeekVisible: true,

            //Day Changed
            onDaySelected: (DateTime selectDay, DateTime focusDay) {
              setState(() {
                selectedDay = selectDay;
                focusedDay = focusDay;
                //percentProvider.todoPercentageProvider(selectedDay);
              });
              print(focusedDay);
            },
            selectedDayPredicate: (DateTime date) {
              return isSameDay(selectedDay, date);
            },

            holidayPredicate: (day){
              return day.day == 10;
            },

            eventLoader:(DateTime date){
             return _getPercentsfromDay(date);

            },

            //To style the Calendar
            calendarStyle: CalendarStyle(

                isTodayHighlighted: true,

                //일정 있을 때 표시
                markersAnchor: 0.8,
                markerSize: 15,
                markerDecoration: BoxDecoration(
                  // ignore: unrelated_type_equality_checks
                  color: selectedPercents == '100' ? Colors.deepOrange : Colors.blue,
                  shape: BoxShape.circle,
                ),


                //default = 평일
                defaultDecoration: BoxDecoration(
                  shape: BoxShape.rectangle,
                  borderRadius: BorderRadius.circular(5.0),
                ),
                defaultTextStyle: TextStyle(color: Colors.black),

                //selected 선택한 날짜
                selectedDecoration: BoxDecoration(
                  color: Colors.yellow,
                  shape: BoxShape.rectangle,
                  borderRadius: BorderRadius.circular(5.0),
                ),
                selectedTextStyle: TextStyle(color: Colors.black),

                //today 오늘
                todayDecoration: BoxDecoration(
                    border: Border.fromBorderSide(
                        BorderSide(
                            color: Colors.black54,
                            width: 1.4
                        )
                    ),
                    shape: BoxShape.rectangle
                ),
                todayTextStyle: TextStyle(color: Colors.black87),
                //주말
                weekendDecoration: BoxDecoration(
                  shape: BoxShape.rectangle,
                  borderRadius: BorderRadius.circular(5.0),
                ),
                weekendTextStyle: TextStyle(color: Colors.black54),


                holidayTextStyle: TextStyle(color:Colors.deepOrange),
                holidayDecoration: BoxDecoration(
                border: Border.fromBorderSide(
                BorderSide(
                    color: Colors.lightGreen,
                    width: 1.4
                  )
                ),
                shape: BoxShape.rectangle,
                  borderRadius: BorderRadius.circular(5.0),
              ),

            ),
            headerStyle: HeaderStyle(
              titleCentered: true,

              //먼스 버튼
              formatButtonVisible: true,
              formatButtonShowsNext: false,

              /*
              formatButtonDecoration: BoxDecoration(
                color: Colors.blue,
                borderRadius: BorderRadius.circular(5.0),
              ),
              formatButtonTextStyle: TextStyle(
                color: Colors.white,
              ),
              */

            ),
          ),
           Text('달성도 ${selectedPercents[selectedDay]} %'),
           Text('달성도 ${percentProvider.getPercent()} %'),

           //일정 목록 나오는 것
          ..._getEventsfromDay(selectedDay).map(
            (Event event) => ListTile(
              title: Text(
                event.percent,
              ),
            ),
          ),
        ],
      ),


      ///add event
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text("Add Event"),
            content: TextFormField(
              controller: _eventController,
            ),
            actions: [
              TextButton(
                child: Text("Cancel"),
                onPressed: () => Navigator.pop(context),
              ),
              TextButton(
                child: Text("Ok"),
                onPressed: () {
                  if (_eventController.text.isEmpty) {
                    selectedPercents[selectedDay].add(
                      percentProvider.getPercent(),
                    );
                  } else {
                    if (selectedPercents[selectedDay] != null) {
                      selectedPercents[selectedDay].add(
                        percentProvider.getPercent(),
                      );
                    } else {
                      selectedPercents[selectedDay] = [
                        percentProvider.getPercent(),
                        //Event(percent: _eventController.text)
                      ];
                    }

                  }
                  Navigator.pop(context);
                  _eventController.clear();
                  setState((){});
                  return;
                },
              ),
            ],
          ),
        ),
        label: Text("Add Event"),
        icon: Icon(Icons.add),
      ),
    );
  }
}
