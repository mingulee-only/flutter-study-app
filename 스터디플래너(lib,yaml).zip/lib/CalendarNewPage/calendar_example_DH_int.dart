import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:table_calendar/table_calendar.dart';

class CalendarExample extends StatefulWidget {
  @override
  _CalendarExampleState createState() => _CalendarExampleState();
}

class _CalendarExampleState extends State<CalendarExample> {
  CalendarFormat _calendarFormat = CalendarFormat.month;
  List<int> _eventTitleList = [];


  @override
  void initState() {
    super.initState();
    Provider.of<CalendarDataViewModel>(context, listen: false).initDate();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Consumer<CalendarDataViewModel>(
        builder: (_, viewModel, __) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TableCalendar(
                firstDay: DateTime(2021, 5, 1),
                lastDay: DateTime(2040, 5, 1),
                focusedDay: viewModel.model.focusedDay,
                calendarFormat: _calendarFormat,
                eventLoader: (day) => viewModel.getEventDaysList(day),
                selectedDayPredicate: (day) {
                  return isSameDay(viewModel.model.selectedDay, day);
                },
                onDaySelected: (selectedDay, focusedDay) {
                  if (!isSameDay(viewModel.model.selectedDay, selectedDay)) {
                    viewModel.setSelectedDays(selectedDay, focusedDay);
                    _eventTitleList = viewModel.getSelectedDayList(selectedDay);
                  }
                },
                onFormatChanged: (format) {
                  if (_calendarFormat != format) {
                    _calendarFormat = format;
                  }
                },
                onPageChanged: (focusedDay) {
                  viewModel.model.focusedDay = focusedDay;
                },
              ),
              _eventTitleList.isEmpty
                  ? Container()
                  : ListView.builder(
                      shrinkWrap: true,
                      itemCount: _eventTitleList.length,
                      itemBuilder: (_, index) {
                        int text = _eventTitleList[index];
                        return Card(child: ListTile(title: Text(text.toString())));
                      })
            ],
          );
        },
      ),
    );
  }
}

class CalendarDataModel {
  DateTime focusedDay = DateTime.now();
  DateTime selectedDay = DateTime.now();
  Map<DateTime, List<int>> selectedDayList;

  CalendarDataModel({this.focusedDay, this.selectedDay, this.selectedDayList});
}

class CalendarDataViewModel extends ChangeNotifier {
  CalendarDataModel model = CalendarDataModel();
  String percent;

  void initDate() async {
    DateTime currentTime = DateTime.now();
    model.focusedDay = currentTime;

    model.selectedDayList = {
      getDate(currentTime): [11, 22, 33],
      getDate(currentTime.add(Duration(days: 2))): [67, 27],
      getDate(currentTime.add(Duration(days: 5))): [27],
      DateTime(2021, 5, 27) : [70]
    };
  }

  Future<String> getPercent(DateTime dateTime) async {
    String todayDate = DateFormat('yyyyMMdd').format(dateTime);

    //그 날짜의 모든 todo 개수
    final QuerySnapshot todayAllResult =
        await FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo').doc('date')
        .collection(todayDate)
        .get();

    //그 날짜의 모든 todo 개수 중 isdone이 true인 경우의 개수
    final QuerySnapshot todayDoneResult =
        await FirebaseFirestore.instance.collection('Todolist')
        .doc('vI8ZL7pCaCCOZaQeexZv').collection('Todo').doc('date')
        .collection(todayDate).where('isDone', isEqualTo: true)
        .get();


    //각각 리스트로 만듬
    final List<DocumentSnapshot> todayDoneDocuments = todayDoneResult.docs;
    final List<DocumentSnapshot> todayAllDocuments = todayAllResult.docs;

    //개수 세서 계산
    if(todayAllDocuments.length == 0){
      percent = null;
    } else {
      var _tileCount = todayDoneDocuments.length;
      double cal = _tileCount / (todayAllDocuments.length);
      percent = (cal * 100.floor()).toInt().toString();
    }
    
    return Future.delayed(Duration(seconds: 4), () => percent );

  }
  
  void setSelectedDays(DateTime sDay, DateTime fDay) {
    model.selectedDay = sDay;
    model.focusedDay = fDay;
    notifyListeners();
  }

  List<int> getSelectedDayList(DateTime dateTime) {
    DateTime day = getDate(dateTime);
    if (model.selectedDayList[day] == null) {
      return [];
    } else {
      return model.selectedDayList[day];
    }
  }

  DateTime getDate(DateTime time) {
    return DateTime(time.year, time.month, time.day);
  }

  List<dynamic> getEventDaysList(DateTime dateTime) {
    DateTime day = getDate(dateTime);

    List eventList = [];

    if (model.selectedDayList.keys.contains(day)) {
      eventList.add(day);
    }

    return eventList;
  }
}
