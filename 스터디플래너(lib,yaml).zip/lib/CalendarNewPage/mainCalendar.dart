
import 'package:flutter/material.dart';

import 'calendar.dart';

void main() {
  runApp(mainCalendar());
}

class mainCalendar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "table calendar test",
      home: CalendarPage(),
    );
  }
}
